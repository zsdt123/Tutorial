require("ai.e.ai-LV5")


function OnStartOfDuel()
	local d=Duel.GetFieldGroup(0, LOCATION_DECK,0)
	local dc=d:GetFirst()
	local e1=Effect.CreateEffect(dc)
    e1:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
    e1:SetCode(EVENT_ADJUST)
    e1:SetOperation(function(e,tp,eg,ep,ev,re,r,rp)
	AI.Chat("")
	AI.Chat("")
	AI.Chat("")
	AI.Chat("你好,这是作弊等级5的AI，AI将在第二次抽卡后+3张,AI每回合增加特定卡7张,")
	AI.Chat("每回合AI+500LP,你-500LP,祝你游戏愉快")

		if  Get_Card_Count(OppST()) >= 0 then
			require("ai.e.ai-special-5")
			OnStartOfDuel()
		end
	
		if Get_Card_Count(OppST()) >= 10 then
			require("ai.e.ai-special-1")
			OnStartOfDuel()
		end
		e:Reset()
	end)
	Duel.RegisterEffect(e1,1)
end

function OnStartOfDuel_Boss()
	local cheat1=EnableCheats
	local cheat2=EnableCheats2
	local list=TokenList
	EnableCheats=function ()
		cheat1()
	
	end
	local savc=SaveCards
	SaveCards=function()
		if player_ai==nil then 
			player_ai=1
			playersetupcomplete = true
			EnableCheats()
		end		
		savc()
	end
	GlobalCheating = 1
	----------------
	
	local f0=ChaosDragonOnSelectInit
	ChaosDragonOnSelectInit=function(cards, to_bp_allowed, to_ep_allowed)
		if HasID(cards.activatable_cards,24696097) then
			return {COMMAND_ACTIVATE,CurrentIndex}
		end
		f0(cards, to_bp_allowed, to_ep_allowed)
	end
end

function EnableCheats2(list)
  local e1=Effect.GlobalEffect()
  e1:SetType(EFFECT_TYPE_CONTINUOUS+EFFECT_TYPE_FIELD)
  e1:SetCode(EVENT_PHASE+PHASE_DRAW)
  e1:SetCountLimit(1)
  e1:SetCondition(function(e,tp,eg,ep,ev,re,r,rp)
    return Duel.GetTurnPlayer()==player_ai
  end)
  e1:SetOperation(function(e,tp,eg,ep,ev,re,r,rp) 
		local tc=Duel.CreateToken(player_ai,list[math.random(#list)])
	local tccode=tc:GetOriginalCode()
	if tc:IsType(TYPE_MONSTER) and Duel.GetLocationCount(player_ai,LOCATION_MZONE)>0 then
		if not TokenSumType[tccode] then TokenSumType[tccode]=TokenSumType[bit.band(tc:GetType(),TYPE_FUSION)] end
		if TokenSumType[tccode]==0 then TokenSumType[tccode]=TokenSumType[bit.band(tc:GetType(),TYPE_RITUAL)] end
		if TokenSumType[tccode]==0 then TokenSumType[tccode]=TokenSumType[bit.band(tc:GetType(),TYPE_SYNCHRO)] end
		if TokenSumType[tccode]==0 then TokenSumType[tccode]=TokenSumType[bit.band(tc:GetType(),TYPE_XYZ)] end
		if TokenSumType[tccode]==0 then TokenSumType[tccode]=TokenSumType[bit.band(tc:GetType(),TYPE_PENDULUM)] end
		if not tc:IsCanBeSpecialSummoned(e,TokenSumType[tccode],player_ai,true,true) then return end
		if ExpansionCheating[tccode] then 
			ExpansionCheating[tccode](tc)
		else
			ExpansionCheating[bit.band(tc:GetType(),TYPE_XYZ)](tc,0,0,0,0,0)
		end
	elseif tc:IsType(TYPE_SPELL+TYPE_TRAP) and Duel.GetLocationCount(player_ai,LOCATION_SZONE)>0 then
		Duel.MoveToField(tc,player_ai,player_ai,LOCATION_SZONE,POS_FACEDOWN,true)
	end
	tc=Duel.CreateToken(player_ai,handlist[math.random(#handlist)])
	Duel.SendtoHand(tc,player_ai,REASON_RULE)
	tc=Duel.CreateToken(player_ai,pawnlist[math.random(#pawnlist)])
	  if Duel.GetLocationCount(player_ai,LOCATION_MZONE)>3 then
	  Duel.MoveToField(tc,player_ai,player_ai,LOCATION_MZONE,POS_ATTACK,true)
	  else
	  Duel.SendtoGrave(tc,player_ai,REASON_RULE)
	 end
  end)
  Duel.RegisterEffect(e1,player_ai)
end

pawnlist={}



