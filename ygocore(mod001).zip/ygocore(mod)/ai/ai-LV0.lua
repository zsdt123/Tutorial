Version = "0.28c"
Experimental = true

--[[
  AI Script for YGOPro Percy:
  http://www.ygopro.co/

  script by Snarky
  original script by Percival18
  
  GitHub repository: 
  https://github.com/Snarkie/YGOProAIScript/
  
  Check here for updates: 
  http://www.ygopro.co/Forum/tabid/95/g/posts/t/7877/AI-Updates
  
  Contributors: ytterbite, Sebrian, Skaviory, francot514
  
  for more information about the AI script, check the ai-template.lua
]]
function requireoptional(module)
  if not pcall(require,module) then
    --print("file missing or syntax error: "..module)
  end
end
require("ai.mod2.AICheckList")
require("ai.mod2.AIHelperFunctions")
require("ai.mod2.AIHelperFunctions2")
require("ai.mod2.AICheckPossibleST")
require("ai.mod2.AIOnDeckSelect")
require("ai.mod2.DeclareAttribute")
require("ai.mod2.DeclareCard")
require("ai.mod2.DeclareMonsterType")
require("ai.mod2.SelectBattleCommand")
require("ai.mod2.SelectCard")
require("ai.mod2.SelectChain")
require("ai.mod2.SelectEffectYesNo")
require("ai.mod2.SelectInitCommand")
require("ai.mod2.SelectNumber")
require("ai.mod2.SelectOption")
require("ai.mod2.SelectPosition")
require("ai.mod2.SelectSum")
require("ai.mod2.SelectTribute")
require("ai.mod2.SelectYesNo")
require("ai.decks2.Generic")
require("ai.decks2.FireFist")
require("ai.decks2.HeraldicBeast")
require("ai.decks2.Gadget")
require("ai.decks2.Bujin")
require("ai.decks2.Mermail")
require("ai.decks2.Shadoll")
require("ai.decks2.Satellarknight")
require("ai.decks2.ChaosDragon")
require("ai.decks2.HAT")
require("ai.decks2.Qliphort")
require("ai.decks2.NobleKnight")
require("ai.decks2.Necloth")
require("ai.decks2.BurningAbyss")
require("ai.decks2.DarkWorld")
require("ai.decks2.Constellar")
require("ai.decks2.Blackwing")
require("ai.decks2.Harpie")
require("ai.decks2.HERO")
require("ai.decks2.ExodiaLib")
require("ai.decks2.Boxer")
require("ai.decks2.Cth")
require("ai.decks2.Spellbook")
require("ai.decks2.X-Saber")
require("ai.decks2.Wizard")
require("ai.decks2.Express")




math.randomseed( require("os").time() )


function OnStartOfDuel()
  AI.Chat("")
	AI.Chat("")
  AI.Chat("")
	AI.Chat("")
  AI.Chat("AI会用部分禁卡拉近和玩家之间的战斗力差，觉得AI太弱可以调高【AI作弊强度】")
	AI.Chat("觉得AI太强可以打开【deck】文件夹，解压【容易】AI卡组（无禁卡）.rar")
  SaveState()
end


