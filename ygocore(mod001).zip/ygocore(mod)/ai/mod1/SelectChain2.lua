--- OnSelectChain --
--
-- Called when AI can chain a card.
-- This function is not completely implemented yet. The parameters will very likely change in the next version.
-- 
-- Parameters:
-- cards = table of cards to chain
-- only_chains_by_player = returns true if all cards in the chain are used by the Player
-- Return: 
-- result
--		1 = yes, chain a card
--		0 = no, don't chain
-- index = index of the chain

function OnSelectChain(cards,only_chains_by_player)
  local result = 0
  local index = 1
  local ChainAllowed = 0
  
  print("OnSelectChain")
  for i=1,#cards do
    print("Can chain these cards: "..cards[i].id)
  end
  
  ------------------------------------------
  -- The first time around, it sets the AI's
  -- turn (only if the AI is playing second).
  -------------------------------------------
  if GlobalAIPlaysFirst == nil then
    if Duel.GetTurnCount() == 2 then
      GlobalIsAIsTurn = 1
      GlobalAIPlaysFirst = 0
      ResetOncePerTurnGlobals()
	  Globals()
	end
  end

  ----------------------------------------------
  -- This switches the GlobalIsAIsTurn variable.
  ----------------------------------------------
  if GlobalAIPlaysFirst == 1 then
    if GlobalIsAIsTurn == 1 then
      if Duel.GetTurnCount() % 2 == 0 then
        GlobalIsAIsTurn = 0
        ResetOncePerTurnGlobals()
	  end
    end
    if GlobalIsAIsTurn == 0 then
      if Duel.GetTurnCount() % 2 == 1 then
        GlobalIsAIsTurn = 1
        ResetOncePerTurnGlobals()
	  end
    end
  end
  if GlobalAIPlaysFirst == 0 then
    if GlobalIsAIsTurn == 1 then
      if Duel.GetTurnCount() % 2 == 1 then
        GlobalIsAIsTurn = 0
        ResetOncePerTurnGlobals()
	  end
    end
	if GlobalIsAIsTurn == 0 then
      if Duel.GetTurnCount() % 2 == 0 then
        GlobalIsAIsTurn = 1
        ResetOncePerTurnGlobals()
	  end
    end
  end
  	 
  ---------------------------------------------------------
  -- Compare the current field's state with the previously
  -- saved field state, and get the card  that the opponent
  -- has played or modified. If the opponent did summon,
  -- modify or activate something, this variable will be
  -- non-zero.
  ---------------------------------------------------------
  local OppCard = GetPlayedCard()
  local OppCardType = 0
  local OppCardOwner = 0

  --------------------------------------------------
  -- Nil values give me debug nightmares so here's a
  -- "catch" routine to determine a type value of a
  -- non-existant card.
  --------------------------------------------------
  if OppCard ~= 0 then
    OppCardType = OppCard.type
    OppCardOwner = OppCard.owner
  end

  
  ---------------------------------------------------
  -- Check if Trap or Spell cards shouldn't be activated here.
  -- 
  -- For now it simply checks if Royal Decree or Imperial Order
  -- is face up on the field.
  ---------------------------------------------------
  local TrapsNegated = FaceUpCardExists(51452091)
  local SpellsNegated = FaceUpCardExists(61740673)
  ---------------------------------------------
  -- Don't activate anything if the AI controls
  -- a face-up Light and Darkness Dragon.
  ---------------------------------------------
  if AIControls(47297616) == 1 then
    return 0,0
  end

 ---------------------------------------------
 -- Cocoon of Evolution on field turn counter
 --------------------------------------------- 
 if Global1PTVariable ~= 1 and GlobalIsAIsTurn == 1 then
  if AIControlsFaceUP(40240595) == 1 and AIControlsFaceUP(58192742) == 1 and AI.GetCurrentPhase() == PHASE_END then -- Cocoon of Evolution, Petit Moth
    GlobalCocoonTurnCount = GlobalCocoonTurnCount +1
    Global1PTVariable = 1
	 else if AIControlsFaceUP(40240595) == 0 or AIControlsFaceUP(58192742) == 0 then
       GlobalCocoonTurnCount = 0
      end
    end
  end  
  
  -----------------------------------------------------
  -- Check if global chaining conditions are met,
  -- and set ChainAllowed variable to 1 if they are.
  -----------------------------------------------------
  for i=1,#cards do
   if AIControlsFaceupST(cards[i].id) ~= 1 or
	  MultiActivationOK(cards[i].id) == 1 then 
	  if bit32.band(cards[i].type,TYPE_MONSTER) > 0 or (bit32.band(cards[i].type,TYPE_TRAP) > 0 and TrapsNegated ~= 1) or (bit32.band(cards[i].type,TYPE_SPELL) > 0 and SpellsNegated ~= 1) then		
		if (isUnchainableTogether(cards[i].id) == 1 and AIControlsFaceupUnchainable(cards[i].id) == 0) or isUnchainableTogether(cards[i].id) == 0 then  -- Checks if any cards from UnchainableTogether list are already in chain.
          if (isUnactivableWithNecrovalley(cards[i].id) == 1 and FaceUpCardExists(47355498) ~= 1) or isUnactivableWithNecrovalley(cards[i].id) == 0 then -- Check if card shouldn't be activated when Necrovalley is on field
		   ChainAllowed = 1
		   end
         end
       end
     end
   end
  
  -----------------------------------------------------
  -- Proceed to chain any cards and check other chaining
  -- conditions, only if global restrictions above are met.
  -----------------------------------------------------
  if ChainAllowed == 1 then
  
  
  ------------------------------------------
  -- If the opponent activated a Trap card,
  -- the AI should chain "Royal Decree" and 
  -- "Trap Stun" first.
  ------------------------------------------
    for i=1,#cards do
      if cards[i].id == 51452091 or cards[i].id == 59616123 then
        if AIControlsFaceupST(51452091) == 0 and AIControlsFaceupST(59616123) == 0 then
		if OppCard ~= nil and OppCardOwner == 2 then
          if bit32.band(OppCard.type,TYPE_TRAP) > 0 and OppCard.position == POS_FACEUP then
            GlobalActivatedCardID = cards[i].id
             return 1,i
            end
          end
        end
      end
    end
    
  ---------------------------------------------------
  -- Activate Mystical Space Typhoon at the End Phase
  -- if the opponent has any existing Spells/Traps.
  ---------------------------------------------------
  if AI.GetCurrentPhase() == PHASE_END then
    for i=1,#cards do
      if cards[i].id == 05318639 and
         OppSTCount() > 0 and AIControlsFaceupST(05318639) ~= 1 then
        GlobalActivatedCardID = cards[i].id
		return 1,i
      end
    end
  end

  --------------------------------------------------------
  -- Activate Mystical Space Typhoon any time the opponent
  -- plays a continuous Spell/Trap or a Field Spell.
  --------------------------------------------------------
  for i=1,#cards do
    if cards[i].id == 05318639 and AIControlsFaceupST(05318639) ~= 1 then
      local OppST = AI.GetOppSpellTrapZones()
      for x=1,#OppST do
        if OppST[x] ~= false then
          if OppST[x].position == POS_FACEUP then
            if OppST[x].type == TYPE_CONTINUOUS + TYPE_SPELL or
               OppST[x].type == TYPE_CONTINUOUS + TYPE_TRAP  or
               OppST[x].type == TYPE_FIELD      + TYPE_SPELL then
			   GlobalActivatedCardID = cards[i].id
              return 1,i
            end
          end
        end
      end
    end
  end

  -------------------------------------------------
  -- Activate Torrential Tribute if the opponent
  -- controls at least 2 more monsters than the AI.
  -------------------------------------------------
	for i=1,#cards do
      if cards[i].id == 53582587 and
         OppMonCount() >= AIMonCount() + 2 then
        GlobalActivatedCardID = cards[i].id
        return 1,i
       end
     end
  
  ---------------------------------
  -- Activate Raigeki Break or Phoenix Wing Wind Blast only if
  -- the opponent controls a card.
  ---------------------------------
    for i=1,#cards do
      if cards[i].id == 04178474 or -- Raigeki B
         cards[i].id == 63356631 then -- Phoenix Wing Wind Blast
        if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() or OppSTCount() > 0 then
          GlobalActivatedCardID = cards[i].id
          GlobalCardMode = 1
		  return 1,i
        end
      end
    end

  ----------------------------------
  -- Activate Icarus Attack only if
  -- the opponent controls 2+ cards.
  ----------------------------------
    for i=1,#cards do
      if cards[i].id == 53567095 then
        if OppMonCount() + OppSTCount() >= 2 then
          GlobalActivatedCardID = cards[i].id
          return 1,i
        end
      end
    end

  ----------------------------------------------------------------
  -- Activate Beckoning Light only if the number of LIGHT monsters
  -- in the AI's graveyard is 5 or more, and also greater than or
  -- equal to the number of cards in the AI's hand (at least 4)
  ----------------------------------------------------------------
    for i=1,#cards do
      if cards[i].id == 16255442 then
        local AIHand = AI.GetAIHand()
        if CountAttributeMonstersInGrave(ATTRIBUTE_LIGHT) >= 5 and
           #AIHand >= 4 then
          GlobalActivatedCardID = cards[i].id
          return 1,i
        end
      end
    end
       
  -------------------------------------------------------
  -- Activate Zero Gardna's effect in the Draw Phase.
  -- This will help the AI to use this effect only on the
  -- opponent's turn.
  -------------------------------------------------------
  if AI.GetCurrentPhase() == PHASE_DRAW then
    for i=1,#cards do
      if cards[i].id == 93816465 then
        return 1,i
      end
    end
  end

  -------------------------------------------
  -- Activate Number 39: Utopia's effect only
  -- if it's the opponent's turn for now.
  -------------------------------------------
  for i=1,#cards do
    if cards[i].id == 84013237 and
       GlobalIsAIsTurn == 0 then
      GlobalActivatedCardID = cards[i].id
      return 1,i
    end
  end

  ----------------------------------------------
  -- Activate Formula Synchron's "Accel Synchro"
  -- effect if the AI hasn't already attempted
  -- it yet this turn.
  ----------------------------------------------
  for i=1,#cards do
    if cards[i].id == 50091196 and
       Global1PTFormula ~= 1 then
      Global1PTFormula = 1
      GlobalActivatedCardID = cards[i].id
      return 1,i
    end
  end

  ---------------------------------------------
  -- Always try to activate Stardust Dragon's
  -- or SD/AM's "summon from graveyard" effect.
  ---------------------------------------------
  if OppCard ~= nil then
    for i=1,#cards do
      if cards[i].id == 44508094 or cards[i].id == 61257789 then
        if cards[i].location == LOCATION_GRAVE then
          return 1,i
        end
      end
    end
  end
  
  ---------------------------------------------
  -- AI should activate: Fiendish Chain, 
  -- only if player has any face up effect monsters on the field
  --------------------------------------------- 
   for i=1,#cards do 
   if cards[i].id == 50078509 then -- Fiendish Chain 
	if OppMonEffectCountFaceUp() > 0 then
     return 1,i
     end
    end
   end
      
  ---------------------------------------------
  -- Activate Gladiator Beast War Chariot,
  -- only if Opp controls effect type monsters
  ---------------------------------------------
  for i=1,#cards do 
   if cards[i].id == 96216229 then -- Gladiator Beast War Chariot
	 if OppMonEffectCountFaceUp() > 0 then
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
    end    
   end
  
  ---------------------------------------------
  -- AI should activate: Waboku, Negate Attack 
  -- only if player has any face up attack position monsters 
  -- with more attack points than AI's stronger attack pos monster
  --------------------------------------------- 
  if GlobalIsAIsTurn == 0 and Global1PTWaboku ~= 1 then
   for i=1,#cards do 
   if cards[i].id == 12607053 or cards[i].id == 14315573 then -- Waboku, Negate Attack
   if GetOppMonstersHighestAPosATK() > GetAIMonstersHighestATKDEF() or 
    AIMonCount() == 0 and AIMonCountFaceUpAttack() > 0 then
	 Global1PTWaboku = 1 
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
  end
 
  ---------------------------------------------
  -- AI should activate: Compulsory Evacuation Device,
  -- only if player has level 5+ or special summon monster on the field
  ---------------------------------------------
   for i=1,#cards do
   if cards[i].id == 94192409 then -- Compulsory Evacuation Device
    if OppMonCountHigherLevelOrSS(5) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
   
  ---------------------------------------------
  -- AI should activate: Honest, if any AI's 
  -- light monster is being attacked
   ---------------------------------------------
   for i=1,#cards do
   if cards[i].id == 37742478 then -- Honest
    if AIAttackedLightMonCount() > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
 
  ---------------------------------------------
  -- AI should activate: Shadow Spell,
  -- only if player has stronger attack position monster than any of AI's
  -- and player's monster has 2000 attack points or more.
  ---------------------------------------------
   for i=1,#cards do
   if cards[i].id == 29267084 then -- Shadow Spell
    if GetOppMonstersHighestAPosATK() >= 2000 and (GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK()) then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
  
  ---------------------------------------------
  -- AI should activate: Return from the Different Dimension,
  -- only if AI can bring out strong tribute monster as result, 
  -- or if player or AI has 0 monsters on the field (just in case)
  ---------------------------------------------
   for i=1,#cards do
   if cards[i].id == 27174286 then -- Return from the Different Dimension
     local AIHand = AI.GetAIHand()
     local HandHighestATK = 0
     local Result = 0
   if AI.GetCurrentPhase() == PHASE_BATTLE and GlobalIsAIsTurn == 0 and CountAIMonstersBanished() >= 3 and AIMonCount() == 0 then 
    return 1,i
   end
   if AI.GetCurrentPhase() == PHASE_MAIN1 and CountAIMonstersBanished() >= 3 and GlobalIsAIsTurn == 1 and AIMonCount() == 0 then	
    for x=1,#AIHand do
	if AIHand[x] ~= false then
     if AIHand[x].attack > HandHighestATK then
     HandHighestATK = AIHand[x].attack       
      if AIHand[x].level >= 5 and
       HandHighestATK >= GetOppMonstersHighestAPosATK() then
	    return 1,i 
	   end
     end
   end
 end
   end
     end 
   end
  
  ---------------------------------------------
  -- AI should activate: The Flute of Summoning Dragon, 
  -- only if AI's strongest monster's attack points are 
  -- 1500 or higher and AI's lp is lower than player's
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 72989439 then  -- Black Luster Soldier - Envoy of the Beginning
    if AIControlsFaceUP(31305911) == 1 or GetOppMonstersHighestAPosATK() > GetAIMonstersHighestATK() then
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Zero Gravity, 
  -- only if Player is about to attack or attacked.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 83133491 then  -- Zero Gravity
    if AIControlsFaceUP(83133491) ~= 1 and AI.GetCurrentPhase() == PHASE_DAMAGE and GlobalIsAIsTurn == 0 then
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: The Flute of Summoning Dragon, 
  -- only if AI's strongest monster's attack points are 
  -- 1500 or higher and AI's lp is lower than player's
  ---------------------------------------------
   for i=1,#cards do    
   if cards[i].id == 98045062 then -- Enemy Controller
	if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() and GetAIMonstersHighestATK() > HighestATKMonsterAPosDEF() then
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  ---------------------------------------------------
  -- Use these cards only on opponents cards.
  -- TODO: Expand card list
  ---------------------------------------------------
  if OppCard ~= nil then
  if OppCardOwner == 2 then
    for i=1,#cards do
	  if cards[i].id == 41420027 or cards[i].id == 84749824 or 
	     cards[i].id == 03819470 or cards[i].id == 77538567 then     
       GlobalActivatedCardID = cards[i].id 
		return 1,i
       end
      end
    end
   end
   
  ---------------------------------------------------------
  -- Activate Stardust Dragon/etc's effect, 
  -- or Starlight Road only if the
  -- opponent activated something.
  ---------------------------------------------------------
  if OppCard ~= nil then
    for i=1,#cards do
      if cards[i].id == 44508094 or cards[i].id == 58120309 or   -- SD, SR
         cards[i].id == 61257789 or cards[i].id == 35952884 or   -- SDAM, SQD
         cards[i].id == 24696097 or cards[i].id == 99188141 then -- SSD,THRIO
        return 1,i
      end
    end
  end
  
  ---------------------------------------------
  -- AI should apply equip power up cards
  -- only to his own monsters.
  -- 
  -- Elf's Light - activate only if AI has one or more 
  -- light attribute monster on the field 
  ---------------------------------------------
   for i=1,#cards do   
   if cards[i].id == 39897277 then -- Elf's Light
    if AICountAttributeMonstersOnField(ATTRIBUTE_LIGHT, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end
 end   
  for i=1,#cards do   
   if cards[i].id == 18937875 then -- Burning Spear
    if AICountRaceMonstersOnField(ATTRIBUTE_FIRE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end   
 end    
   for i=1,#cards do  
   if cards[i].id == 86198326 or  -- 7 Completed
      cards[i].id == 63851864 then -- Break! Draw!
    if AICountRaceMonstersOnField(RACE_MACHINE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end   
 end  
  for i=1,#cards do  
   if cards[i].id == 88190790 then -- Assault Armor
    if AICountRaceMonstersOnField(RACE_WARRIOR, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) == 1 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end     
 end  
  for i=1,#cards do  
   if cards[i].id == 46009906 then -- Beast Fangs
    if AICountRaceMonstersOnField(RACE_BEAST, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end 
 end
  for i=1,#cards do  
   if cards[i].id == 91595718 or -- Book of Secret Arts
      cards[i].id == 53610653 then -- Bound Wand
    if AICountRaceMonstersOnField(RACE_SPELLCASTER, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
    end
  end 
 end 
  
  ---------------------------------------------
  -- Activate Amplifier only if 
  -- AI controls 1 or more "Jinzo" monster.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 00303660 then -- Amplifier 
    if AiControlsFaceUp(77585513) ~= 0 then -- Jinzo      
     GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
    end
  end   
  
  ---------------------------------------------
  -- Activate Bubble Blaster only if 
  -- AI controls 1 or more "Elemental Hero Bubbleman" monster.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 53586134 then -- Bubble Blaster
    if AiControlsFaceUp(79979666) ~= 0 then -- Elemental Hero Bubbleman      
     GlobalActivatedCardID = cards[i].id
	 return 1,i
    end
  end  
 end
  ---------------------------------------------
  -- Activate Amulet of Ambition only if 
  -- AI controls 1 or more normal monsters.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 05183693 then -- Amulet of Ambition
    if AIMonNormalCountFaceUp() > 0 then      
     GlobalActivatedCardID = cards[i].id
	 return 1,i
    end
  end      
 end
  ---------------------------------------------
  -- AI Will activate Bait Doll 
  -- only if player has any spell or trap cards on the field
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 07165085 then -- Bait Doll
    if OppFacedownTrapCount() > 0 then
     GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end 
  ---------------------------------------------
  -- Activate Buster Rancher only if 
  -- AI controls 1 or more monsters with attack points of
  -- 1000 or below.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 84740193 then -- Buster Rancher
    if AIMonAttackPointCountFaceUp(1000) > 0 then      
     GlobalActivatedCardID = cards[i].id
	 return 1,i
    end
  end      
 end
  ---------------------------------------------
  -- AI should activate: Broken Bamboo Sword, 
  -- Cursed Bill, Mask of the accursed, Flint 
  -- only if player has any face up attack position monsters on the field
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 41587307 or -- Broken Bamboo Sword
      cards[i].id == 46967601 or -- Cursed Bill
      cards[i].id == 56948373 or -- Mask of the accursed  
      cards[i].id == 75560629 then -- Flint 
    if OppMonCountFaceUpAttack() > 0 then
     GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
	end
   end
  
  ---------------------------------------------
  -- AI should activate: Armed Changer, Axe of Despair,
  -- Ballista of Rampart Smashing, Big Bang Shot, Black Pendant
  -- 
  -- only if he has any face up position monsters on the field
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 90374791 or -- Armed Changer
      cards[i].id == 00242146 or -- Ballista of Rampart Smashing
      cards[i].id == 61127349 or -- Big Bang Shot
      cards[i].id == 65169794 or -- Black Pendant      
      cards[i].id == 69243953 or -- Butterfly Dagger - Elma
	  cards[i].id == 40619825 then -- Axe of Despair   
    if AIMonCountFaceUp() > 0 then
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end
    
  ---------------------------------------------
  -- AI should activate: Germ Infection, Paralazying Poison 
  -- only if player has any face up monsters non machine race monsters on the field
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 24668830 or -- Germ Infection
      cards[i].id == 50152549 then -- Paralyzing Potion
	if CountOppNonRaceMonstersFaceUp(RACE_MACHINE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
	end
   end
    
  ---------------------------------------------
  -- AI should activate: Chthonian Alliance, 
  -- only if player has face up monsters with same name 
  -- TODO: For now we will check for same id's
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 46910446 then -- Chthonian Alliance 
    if MonCountSameID() > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Dark Core, 
  -- only if player has face up monsters with 1700 
  -- or more attack points.
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 70231910 then -- Dark Core 
    if OppMonAttackPointCountFaceUp(1700) > 0 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
   
  ---------------------------------------------
  -- AI should activate: Soul Release, 
  -- only if AI has 4 or more monster cards in graveyard
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 05758500 then -- Soul Release 
    if CountAIMonstersInGrave() >= 3 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Cost Down, 
  -- only if AI has level 5 or 6 monster in hand
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 23265313 then -- Cost Down
     local AIHand = AI.GetAIHand()
      for x=1,#AIHand do
       if AIHand[x] ~= false and AI.GetCurrentPhase() == PHASE_MAIN1 then
         if (AIHand[x].level == 5 or AIHand[x].level == 6) and AIMonsterCountHandLowerLevel(4) > 0 then
	     return 1,i
        end
      end
     end
    end 
  end
  
  ---------------------------------------------
  -- AI should activate: Shrink, 
  -- only if AI's strongest monster's attack points are 
  -- lower than players strongest attack pos monster's points
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 55713623 then -- Shrink
    if AIMonCountFaceUp() > 0 then
	 if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() and GetAIMonstersHighestATK() > GetOppMonstersHighestAPosATK() / 2 and
	 GetAIMonstersHighestATK() >= 1400 then
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Megamorph, 
  -- only if AI's strongest monster's attack points are 
  -- 1500 or higher and AI's lp is lower than player's
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 22046459 then -- Megamorph
    if AIMonCountFaceUp() > 0 then
	if AI.GetPlayerLP(1) < AI.GetPlayerLP(2) and GetAIMonstersHighestATK() >= 1500 then
     GlobalActivatedCardID = cards[i].id
     return 1,i
     end
    end
   end
  end  
	
  for i=1,#cards do  
   if cards[i].id == 74117290 then -- Dark World Dealings
    if AICardInHand(34230233) ~= 0 or AICardInHand(33731070) ~= 0 
	or AICardInHand(79126789) ~= 0 or AICardInHand(32619583) ~= 0 then
     GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate:  Dark World Lightning, 
  -- only if Player controls any face down cards.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 93554166 then -- Dark World Lightning
    if OppFacedownMonsterCount() > 0 or OppFacedownTrapCount() > 0 then
     GlobalCardMode = 1
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Dragged Down into the Grave, 
  -- only if AI has no other cards then "Dark World" monsters in hand
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 16435215 then -- Dragged Down into the Grave
    if AINonDWCardCountHand() == 0 then
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Mystic Box, 
  -- only if AI has monster with 1400 attack or lower
  -- and opponent controls a strong monster. 
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 25774450 then -- Mystic Box
    if GetOppMonstersHighestAPosATK() > GetAIMonstersHighestATK() and GetOppMonstersHighestAPosATK() >= 2000 and GetAIMonstersLowestATK() <= 1400 then
	 GlobalCardMode = 1
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
   end
  end
  
  ---------------------------------------------
  -- AI should activate: Mage Power, 
  -- only if AI's monster can become stronger than
  -- any player's monster as result.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 83746708 then -- Mage Power
    if (GetAIMonstersHighestATK() + (500 * AISTCount())) >= GetOppMonstersHighestAPosATK() and AIMonCountFaceUp() > 0 then 
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
    end
  end
  
  ---------------------------------------------
  -- AI should activate: Amazoness Archers, 
  -- only if AI's monster can become stronger than
  -- any player's monster as result.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 67987611 then -- Amazoness Archers
    if (GetAIMonstersHighestATK() + 500) >= GetOppMonstersHighestAPosATK() then 
	 GlobalActivatedCardID = cards[i].id
	 return 1,i
     end
    end
  end
  
  ---------------------------------------------
  -- Set global variable to 1 if player activates
  -- "Amazoness Archers" trap card
  ---------------------------------------------
  if OppControlsFaceupST(67987611) == 1 then
   if AI.GetCurrentPhase() == PHASE_BATTLE then
     Global1PTAArchers = 1
    end
  end
  ---------------------------------------------
  -- AI should activate: Swords of Revealing Light, 
  -- only if AI has nothing to summon and player
  -- controls stronger monsters.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 72302403 then -- Swords of Revealing Light
    if AIControlsFaceUP(72302403) ~= 1 then  
     if GetOppMonstersHighestAPosATK() > GetAIMonstersHighestATKDEF() or 
     AIMonCount() == 0 and AIMonCountFaceUpAttack() > 0 then
	   GlobalActivatedCardID = cards[i].id
	    return 1,i
       end
     end
   end
 end 
 
  ---------------------------------------------
  -- AI should activate: Card Destruction, 
  -- only if AI has no other spell or trap cards in hand.
  ---------------------------------------------
  for i=1,#cards do  
   if cards[i].id == 87880531 then -- Diffusion Wave-Motion
    if AIMonsterCountLvlType(RACE_SPELLCASTER,7) > 0 and OppMonCount() >= 2 then
	   GlobalActivatedCardID = cards[i].id
	    return 1,i
       end
     end
   end
  
  ---------------------------------------------
  -- AI should activate: Spellbinding Circle, Mirror Force,  
  -- only if AI's monsters are weaker than players.
  ---------------------------------------------
  for i=1,#cards do   
   if cards[i].id == 18807108 or cards[i].id == 44095762 or -- Spellbinding Circle, Mirror Force
      cards[i].id == 70342110 then                          -- Dimensional Prison
    if GetOppMonstersHighestAPosATK() > GetAIMonstersHighestATK() and GetOppMonstersHighestAPosATK() > GetAIMonstersHighestDEFPosDef() 
	and GetOppMonstersHighestAPosATK() >= 1600 or AI.GetPlayerLP(1) <= 2000 then
	   GlobalActivatedCardID = cards[i].id
	    return 1,i
       end
     end
   end
   
  ---------------------------------------------
  -- AI should activate: Breaker the Magical Warrior's 
  -- effect only if opponent controls any spell or trap cards
  ---------------------------------------------
   for i=1,#cards do  
   if cards[i].id == 71413901 then  -- Breaker the Magical Warrior
    if OppSTCount() > 0 then
	 GlobalActivatedCardID = cards[i].id
     return 1,i
     end
   end
  end
  
  for i=1,#cards do   
   if cards[i].id == 36916401 then  -- Burnin' Boxin' Spirit
	if AIArchetypeMonCountHand(132) > 0 or AIArchetypeMonCountField(132) > 0 then 
	 GlobalActivatedCardID = cards[i].id
	  return 1,i
      end
    end
   end 
    
  ------------------------------------------
  -- Activate "Constellar Pleiades"
  -- if the enemy has a stronger monster
  ------------------------------------------
  for i=1,#cards do
    if cards[i].id == 73964868 then  
      if GetOppMonstersHighestAPosATK() >= GetAIMonstersHighestATK() then
        GlobalActivatedCardID = cards[i].id
        GlobalCardMode = 1
        return 1,i
      end
    end
  end
  
  ----------------------------------------------------------
  -- For now, chain anything else (not already listed above)
  -- that can be chained, except cards with the same ID as
  -- another existing face-up spell/trap card, cards that 
  -- shouldn't be activated in a same chain, and cards that 
  -- shouldn't be activated under certain conditions.
  ----------------------------------------------------------
  
  for i=1,#cards do
   if AIControlsFaceupST(cards[i].id) ~= 1 or
	  MultiActivationOK(cards[i].id) == 1 then 
	 if bit32.band(cards[i].type,TYPE_MONSTER) > 0 or (bit32.band(cards[i].type,TYPE_TRAP) > 0 and TrapsNegated ~= 1) or (bit32.band(cards[i].type,TYPE_SPELL) > 0 and SpellsNegated ~= 1) then
	if (isUnchainableTogether(cards[i].id) == 1 and AIControlsFaceupUnchainable(cards[i].id) == 0) or isUnchainableTogether(cards[i].id) == 0 then  -- Checks if any cards from UnchainableTogether list are already in chain.
   if (isUnactivableWithNecrovalley(cards[i].id) == 1 and FaceUpCardExists(47355498) ~= 1) or isUnactivableWithNecrovalley(cards[i].id) == 0 then -- Check if card shouldn't be activated when Necrovalley is on field
	----------------------------------------------------------------
	----------------------------------------------------------------
	if cards[i].id ~= 05318639 and cards[i].id ~= 53582587 and  -- MST, TT 
       cards[i].id ~= 94192409 and cards[i].id ~= 04178474 and  -- CED, Break
       cards[i].id ~= 53567095 and cards[i].id ~= 93816465 and  -- Icarus, 0G
       cards[i].id ~= 16255442 and cards[i].id ~= 84013237 and  -- Beck, #39
       cards[i].id ~= 41420027 and cards[i].id ~= 84749824 and  -- SJ, SW
       cards[i].id ~= 44508094 and cards[i].id ~= 58120309 and  -- SD, SR
       cards[i].id ~= 61257789 and cards[i].id ~= 35952884 and  -- SDAM, SQD
       cards[i].id ~= 24696097 and cards[i].id ~= 50091196 and  -- SSD,Formula
       cards[i].id ~= 51452091 and cards[i].id ~= 50078509 and  -- Decree, Fiendish Chain,    
       cards[i].id ~= 14315573 and cards[i].id ~= 94192409 and  -- Negate Attack, Compulsory Evacuation Device
	   cards[i].id ~= 12607053 and cards[i].id ~= 96216229 and  -- Waboku, Gladiator Beast War Chariotthen
	   cards[i].id ~= 27174286 and cards[i].id ~= 29267084 and  -- Return from the Different Dimension, Shadow Spell
	   cards[i].id ~= 72989439 and cards[i].id ~= 22046459 and  -- Black Luster Soldier - Envoy of the Beginning, Megamorph
	   cards[i].id ~= 98045062 and cards[i].id ~= 23265313 and  -- Enemy Controller, Cost Down
	   cards[i].id ~= 68005187 and cards[i].id ~= 83133491 and  -- Soul Exchange, Zero Gravity
	   cards[i].id ~= 87880531 and cards[i].id ~= 72302403 and  -- Diffusion Wave-Motion, Swords of Revealing Light
	   cards[i].id ~= 83746708 and cards[i].id ~= 25774450 and  -- Mage Power, Mystic Box
       cards[i].id ~= 16435215 and cards[i].id ~= 93554166 and  -- Dragged Down into the Grave, Dark World Lightning
	   cards[i].id ~= 74117290 and cards[i].id ~= 55713623 and  -- Dark World Dealings, Shrink
       cards[i].id ~= 05758500 and cards[i].id ~= 70231910 and  -- Soul Release, Dark Core
       cards[i].id ~= 46910446 and cards[i].id ~= 24668830 and  -- Chthonian Alliance, Germ Infection
	   cards[i].id ~= 50152549 and cards[i].id ~= 90374791 and  -- Paralyzing Potion, Armed Changer
	   cards[i].id ~= 00242146 and cards[i].id ~= 61127349 and  -- Ballista of Rampart Smashing, Big Bang Shot
       cards[i].id ~= 65169794 and cards[i].id ~= 69243953 and  -- Black Pendant, Butterfly Dagger - Elma      
       cards[i].id ~= 40619825 and cards[i].id ~= 41587307 and  -- Axe of Despair, Broken Bamboo Sword   
	   cards[i].id ~= 46967601 and cards[i].id ~= 56948373 and  -- Cursed Bill, Mask of the accursed 
       cards[i].id ~= 75560629 and cards[i].id ~= 84740193 and  -- Flint, Buster Rancher
	   cards[i].id ~= 07165085 and cards[i].id ~= 05183693 and  -- Bait Doll, Amulet of Ambition
	   cards[i].id ~= 53586134 and cards[i].id ~= 00303660 and  -- Bubble Blaster, Amplifier 
	   cards[i].id ~= 91595718 and cards[i].id ~= 53610653 and  -- Book of Secret Arts, Bound Wand
       cards[i].id ~= 46009906 and cards[i].id ~= 88190790 and  -- Beast Fangs, Assault Armor
	   cards[i].id ~= 86198326 and cards[i].id ~= 63851864 and  -- 7 Completed, Break! Draw!
       cards[i].id ~= 18937875 and cards[i].id ~= 39897277 and  -- Burning Spear, Elf's Light
       cards[i].id ~= 18807108 and cards[i].id ~= 71413901 and  -- Spellbinding Circle, Breaker the Magical Warrior
	   cards[i].id ~= 59616123 and cards[i].id ~= 36916401 and  -- Trap Stun, Burnin' Boxin' Spirit 
	   cards[i].id ~= 44095762 and cards[i].id ~= 67987611 and  -- Mirror Force, Amazoness Archers	 
       cards[i].id ~= 77538567 and cards[i].id ~= 70342110 and  -- Dark Bribe, Dimensional Prison 
	   cards[i].id ~= 37742478 and cards[i].id ~= 73964868 then -- Honest, Constellar Pleiades 
		 GlobalActivatedCardID = cards[i].id 
			return 1,i
          end
         else
            return 0,i
            end       
          end
        end
      end
    end
  
  -------------------------------------
  -- Otherwise don't activate anything.
  -------------------------------------
  return 0,0
  end
end
