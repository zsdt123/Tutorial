--- OnSelectCard ---
--
-- Called when AI has to select a card. Like effect target or attack target
-- Example card(s): Caius the Shadow Monarch, Chaos Sorcerer, Elemental HERO The Shining
-- 
-- Parameters:
-- cards = table of cards to select
-- minTargets = how many you must select min
-- maxTargets = how many you can select max
--
-- Return: 
-- result = table containing target indices
function OnSelectCard(cards, minTargets, maxTargets, triggeringID)
  local result = {}

  print("OnSelectCard",minTargets,maxTargets)
  
  ------------------------------------------------------
  -- This is assuming the AI is attacking.
  --
  -- Obtain the index of the opponent's monster with the
  -- highest ATK/DEF that is below that of the currently
  -- attacking monster, and return that.
  ------------------------------------------------------
  if GlobalAIIsAttacking ~= false and GlobalAttackerID ~= 26593852 then
    if AI.GetCurrentPhase() == PHASE_BATTLE then
      local HighestAttack = 0
      local HighestIndex  = 1
      for i=1,#cards do
        if cards[i] ~= false then
          if cards[i].position == POS_FACEUP_ATTACK then
            if cards[i].attack > HighestAttack and
               cards[i].attack < GlobalCurrentATK and IsUndestroyableByBattle(cards[i].id) == 0 then
			  HighestAttack = cards[i].attack
              HighestIndex = i
            end
          end
          if cards[i].position == POS_FACEUP_DEFENCE then
            if cards[i].defense > HighestAttack and
               cards[i].defense < GlobalCurrentATK and IsUndestroyableByBattle(cards[i].id) == 0 then
			  HighestAttack = cards[i].defense
              HighestIndex = i
            end
          end
          if GlobalAIIsAttacking == 2 and
             cards[i].position == POS_FACEDOWN_DEFENCE then
			HighestAttack = 99999999
            HighestIndex = i
          end
        end
      end
      GlobalAIIsAttacking = false
      result[1]=HighestIndex
	  return result
    end
    GlobalAIIsAttacking = false
  end

  --------------------------------------------
  -- Attack any non dark type monster regardless 
  -- of it's attack.
  --------------------------------------------   
  if GlobalAIIsAttacking ~= false and GlobalAttackerID == 26593852 then
   if AI.GetCurrentPhase() == PHASE_BATTLE then
     for i=1,#cards do
       if cards[i] ~= false then
         if cards[i].position == POS_FACEUP_ATTACK and 
		   IsUndestroyableByBattle(cards[i].id) == 0 and cards[i].attribute ~= ATTRIBUTE_DARK then
             GlobalAIIsAttacking = false
			 GlobalAttackerID = 0
			 result[1]=i
             return result
             end
          end
       end
     end
  end
  
  --------------------------------------------
  -- Select minimum number of valid XYZ material monsters,   
  -- with lowest attack as tributes.
  --------------------------------------------   
 if GlobalSSCardID ~= nil and GlobalSSCardID ~= 91949988 
  and GlobalSSCardType ~= nil and GlobalSSCardType > 0 
  or (PtolemySSMode == 1 and GlobalSSCardID == 38495396 and GlobalSSCardType == nil) then
	local function compare(a,b)
      return a.attack < b.attack
    end
    if GlobalSSCardID == 44505297 then    --Inzektor Exa-Beetle
      GlobalActivatedCardID = GlobalSSCardID
    end
    GlobalSSCardID = nil
    GlobalSSCardType = nil
	PtolemySSMode = nil
	local list = {}
    for i=1,#cards do
      if cards[i] and bit32.band(cards[i].type,TYPE_MONSTER) > 0 
      and IsTributeException(cards[i].id) == 0
      then   
        cards[i].index=i
        list[#list+1]=cards[i]
      end
    end
    table.sort(list,compare)
    result={}
    for i=1,minTargets do
      result[i]=list[i].index
    end
    return result
  end
  
  --------------------------------------------
  -- Select minimum number of valid XYZ material monsters,   
  -- with lowest attack as tributes.
  --------------------------------------------   
 if GlobalSSCardSetcode ~= nil and GlobalSSCardSetcode == 98 or
  GlobalSSCardSetcode == 4522082 then
  local result = {}
  local preferred = {}
  local valid = {}
  local function compare(a,b)
    return a.attack < b.attack
  end
  GlobalSSCardSetcode = nil
  for i=1,#cards do
    if cards[i].owner == 2 or TributeWhitelist(cards[i].id) > 0 or cards[i].type == TYPE_TOKEN then
      preferred[#preferred+1]=i
    elseif cards[i].rank == 0 and cards[i].level <= GlobalSSCardLevel and 
      cards[i].attack < GlobalSSCardAttack and IsTributeException(cards[i].id) == 0 then
      valid[#valid+1]=i
    end
  end
  for i=1,minTargets do
    if preferred[i] then
      table.sort(preferred,compare)
	  result[i]=preferred[i]
    else
      table.sort(valid,compare)
	  result[i]=valid[i-#preferred]
      end
   end
   return result
  end
  
  --------------------------------------------     
  -- Inzektor Exa-Beetle
  -- 4 different selections
  -- *Select strongest available monster to equip from grave
  -- *Select random material to detach
  -- *Select own card to destroy. Prefer equipped monster, then
  --  any spell/traps or himself, otherwise random available card
  -- *Select strongest enemy monster to destroy
  -------------------------------------------- 
  
  if GlobalActivatedCardID == 44505297 then -- Inzektor Exa-Beetle
    if GlobalCardMode == nil then
      GlobalActivatedCardID = nil
      return {HighestATKIndexTotal(cards)}
    end
    GlobalCardMode = GlobalCardMode - 1
    if GlobalCardMode <= 1 then
      GlobalActivatedCardID = nil
      GlobalCardMode = nil
    end
    if GlobalCardMode == 2 then
      return {math.random(#cards)}
    elseif GlobalCardMode == 1 then
      for i=1,#cards do
        if bit32.band(cards[i].type,TYPE_MONSTER) > 0 and cards[i].location == LOCATION_SZONE then 
          return i
        end
        if bit32.band(cards[i].type,TYPE_SPELL) > 0 or bit32.band(cards[i].type,TYPE_TRAP) > 0
        or cards[i].id == 44505297
        then
          result[#result+1]=i
        end
      end 
      if #result==0 then result=cards end
      return {result[math.random(#result)]}
    else
      return {GetHighestATKMonByPos(cards,POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE,2)}
    end
  end
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 90374791 or -- Armed Changer
     GlobalActivatedCardID == 00242146 or -- Ballista of Rampart Smashing
     GlobalActivatedCardID == 61127349 or -- Big Bang Shot
     GlobalActivatedCardID == 65169794 or -- Black Pendant      
     GlobalActivatedCardID == 69243953 or -- Butterfly Dagger - Elma
	 GlobalActivatedCardID == 40619825 then -- Axe of Despair    
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByPos(cards, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
         GlobalActivatedCardID = nil 
		  return result
        end
      end
    end
  
  --------------------------------------------     
  -- Select Players strongest monster, if he controls any
  -- stronger monsters than AI, or select any spell or trap card player controls (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 31386180 then -- Tiras, Keeper of Genesis
   for i=1,#cards do
      if cards[i] ~= false then 
        if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() then 
		 result[1] = HighestATKMonsterIndex(cards, 2)
         GlobalActivatedCardID = nil 
		  else
          result[1] = getRandomSTIndex(cards, 2)
          GlobalActivatedCardID = nil
         end
        return result
      end
    end
  end
  
  --------------------------------------------     
  -- Select Players strongest monster, if he controls any
  -- stronger monsters than AI or only monsters, 
  -- if not select any spell or trap card player controls
  --------------------------------------------   
  if GlobalActivatedCardID == 09748752 then -- Caius the Shadow Monarch
    for i=1,#cards do
      if cards[i] ~= false then 
        if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() or OppSTCount()== 0 then 
          result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil 
        else
          result[1] = getRandomSTIndex(cards, 2)
          GlobalActivatedCardID = nil
        end
        return result
      end
    end
  end
  
  --------------------------------------------     
  -- Check for banished blacklist, 
  -- select the first not on it
  -- TODO: Maybe sort by level or attack, not sure
  --------------------------------------------   
  if GlobalActivatedCardID == 01475311 then -- Allure of Darkness
    for i=1,#cards do
      if cards[i] and BanishBlacklist(cards[i].id) == 0 then 
        result[1]=i
        GlobalActivatedCardID = nil
        return result
      end
    end
  end
  
  --------------------------------------------     
  -- Check, if there are boss monsters in the
  -- grave to return to the hand, otherwise 
  -- bounce the strongest enemy
  -- (currently just checks the banish blacklist
  -- which includes the bosses)
  --------------------------------------------   
  if GlobalActivatedCardID == 38495396 then -- Constellar Ptolemy M7
    if GlobalCardMode == 1 then
      GlobalCardMode = nil
      return {1}
    end
    if AIBossInGraveCount() > 0 then
      for i=1,#cards do
        if cards[i] and BanishBlacklist(cards[i].id) > 0 and 
          cards[i].owner == 1 and cards[i].location == LOCATION_GRAVE then 
          result[1]=i
          GlobalActivatedCardID = nil
          return result
        end
      end
    else
      result[1]=GetHighestATKMonByLoc(cards,LOCATION_MZONE,2)
      GlobalActivatedCardID = nil
      return result
    end
  end
  
  --------------------------------------------     
  -- Constellar Ptolemy M7.
  --------------------------------------------   
  if GlobalSSCardID == 38495396 then -- Constellar Ptolemy M7
   if PtolemySSMode == 2 then  
	PtolemySSMode = nil
	for i=1,#cards do
      if cards[i] ~= false then 
       if bit32.band(cards[i].type,TYPE_XYZ)> 0 and cards[i].setcode == 83 and cards[i].xyz_material_count == 0 then 
		result[1] = i
        GlobalSSCardID = nil
		  return result
          end
        end
      end	
    end
  end
  
  --------------------------------------------     
  -- Select Players strongest face-up monster by attack points on the field.
  -- If there are none, select a random face-down of the player 
  -- (only relevant for BLS)
  --------------------------------------------   
  if (GlobalActivatedCardID == 09596126 or GlobalActivatedCardID == 72989439) -- Chaos Sorcerer, BLS
    and GlobalCardMode == nil then 
    GlobalActivatedCardID = nil
    if OppHasFaceupMonster(0) then 
      result[1] = GetHighestATKMonByPos(cards,POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE,2)
    else
      for i=1,#cards do
        if cards[i] and (cards[i].owner == Owner or CurrentMonOwner(cards[i].id) == Owner) then 
          result[#result+1]=i
        end
      end
    end
    return {result[math.random(#result)]}
  end	
  
  --------------------------------------------     
  -- Select AI's weakest monster by attack points in hand.
  --------------------------------------------   
  if GlobalActivatedCardID == 04178474 then -- Raigeki Break 
   if GlobalCardMode == 1 then
	GlobalCardMode = nil 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = LowestATKMonsterByOwnerIndex(cards, 1)
		 return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select Players strongest monster, if he controls any
  -- stronger monsters than AI, or select any spell or trap card player controls (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 04178474 then -- Raigeki Break
   if GlobalCardMode == nil then
   for i=1,#cards do
      if cards[i] ~= false then 
        if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() then 
		 result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil 
		  else
          result[1] = getRandomSTIndex(cards, 2)
          GlobalActivatedCardID = nil
        end
        return result
        end
      end
    end
  end
 
  ------------------------------------------------------------
  -- Tribute lowest attack monster.
  ------------------------------------------------------------
  if GlobalActivatedCardID == 41426869 then -- Black Illusion Ritual
    for i=1,#cards do
      if cards[i] ~= false then   
	  GlobalActivatedCardID = nil
	  result[1] = LowestATKMonsterIndex(cards)
      return result
      end
    end
  end

  --------------------------------------------     
  -- Select Players random Spell or Trap card
  --------------------------------------------   
  if GlobalActivatedCardID == 05318639 then -- Mystical Space Typhoon 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = getRandomSTIndex(cards, 2)
		  GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  
  --------------------------------------------     
  -- Select Players random Spell or Trap card
  --------------------------------------------   
  if GlobalActivatedCardID == 70908596 then -- Constellar Kaust
   local HighestLVL = 0
	for i=1,#cards do
      if cards[i] ~= false then 
	   if GlobalKaustActivated == nil or AIMonCountID(70908596) > 1 or AIMonsterCountLevel(6, 83) > 0 then
		if bit32.band(cards[i].type,TYPE_MONSTER) > 0 and cards[i].level < 6 and cards[i].setcode == 83 and
		cards[i].level >= HighestLVL and cards[i].position ==(POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) then
         HighestLVL = cards[i].level
		 result[1] = i
		  return result
          end
        end
      end	
    end
	for i=1,#cards do
      if cards[i] ~= false then 
	   if AIMonsterCountLevel(4, 83) > 0 then
		if bit32.band(cards[i].type,TYPE_MONSTER) > 0 and cards[i].level < 5 and cards[i].setcode == 83 and
		cards[i].level >= HighestLVL and cards[i].position ==(POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE) then
         GlobalKaustActivated = 1
		 HighestLVL = cards[i].level
		 result[1] = i
		  return result
          end
        end
      end	
    end
  end	
  
  --------------------------------------------     
  -- Select Players random Spell or Trap card
  --------------------------------------------   
  if GlobalActivatedCardID == 44635489 then -- Constellar Siat
   for i=1,#cards do
      if cards[i] ~= false then 
		if AIMonsterCountLevelField(6, 83) > 0 then
		  if cards[i].level == 6 then
		  result[1] = i
		   GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  for i=1,#cards do
      if cards[i] ~= false then 
		if AIMonsterCountLevelField(5, 83) > 0 then
		  if cards[i].level == 5 then
		  result[1] = i
		  GlobalActivatedCardID = nil
		  return result
          end
        end
      end	
    end
  for i=1,#cards do
      if cards[i] ~= false then 
		if AIMonsterCountLevelField(4, 83) > 0 then
		  if cards[i].level == 4 then
		  result[1] = i
		  GlobalActivatedCardID = nil
		  return result
          end
        end
      end	
    end
  end 
  
  --------------------------------------------     
  -- Select one of the following cards
  --------------------------------------------   
  if GlobalActivatedCardID == 78486968 then -- Constellar Sheratan
	for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 70908596 or cards[i].id == 78364470 or 
		   cards[i].id == 41269771 then 
		  GlobalActivatedCardID = nil
		  result[1] = i
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select monster not of a BanishBlacklist
  --------------------------------------------   
  if GlobalActivatedCardID == 33347467 then -- Ghost Ship
	for i=1,#cards do
      if cards[i] ~= false then 
        if BanishBlacklist(cards[i].id) == 0 then
		 result[1] = i
		  GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  --------------------------------------------     
  -- Select Players random Spell or Trap card
  --------------------------------------------   
  if GlobalActivatedCardID == 71413901 then -- Breaker the Magical Warrior 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = getRandomSTIndex(cards, 2)
		  GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  
  --------------------------------------------     
  -- Select Players strongest monster, if he controls any
  -- stronger monsters than AI, or select any spell or trap card player controls (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 78156759 then -- Wind-Up Zenmaines
   for i=1,#cards do
      if cards[i] ~= false then 
        if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() then 
		 result[1] = HighestATKMonsterIndex(cards, 2)
         GlobalActivatedCardID = nil 
		  else
          result[1] = getRandomSTIndex(cards, 2)
          GlobalActivatedCardID = nil
         end
        return result
      end
    end
  end
  
  --------------------------------------------     
  -- Select any material to detach.
  --------------------------------------------   
  if GlobalActivatedCardID == 73964868 then -- Constellar Pleiades
    if GlobalCardMode == 1 then
	GlobalCardMode = nil
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = i
		  return result
         end
       end
     end	
   end	
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 73964868 then -- Constellar Pleiades
    if GlobalCardMode == nil then 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select any available card (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 06353603 then -- Brotherhood of the Fire Fist - Bear
    if GlobalCardMode == 1 then
	GlobalCardMode = nil
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = i
		  return result
         end
       end
     end	
   end	
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 06353603 then -- Brotherhood of the Fire Fist - Bear
    if GlobalCardMode == nil then 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 74131780 or GlobalActivatedCardID == 80117527 then -- Exiled Force, No. 11 Big Eye 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 54652250 then -- Man-Eater Bug
    for i=1,#cards do
      if cards[i] ~= false then 
        if OppMonCount() > 0 then 
		  result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
	 for i=1,#cards do
       if OppMonCount() == 0 then 
		 if cards[i].id == 54652250 then
		  result[1] = i
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  end
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 64631466 then -- Relinquished
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------     
  -- Detach Battlin' Boxer Switchitter first if possible
  -------------------------------------------- 
  if GlobalActivatedCardID == 34086406 then  -- Lavalval Chain
   if GlobalCardMode == 1 then
   for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 68144350 then -- Battlin' Boxer Switchitter 
		  result[1] = i
		  GlobalCardMode = nil
		  return result
         end
       end
     end	
   end 
 end 
 
  --------------------------------------------     
  -- Discard Glassjaw first if possible
  -------------------------------------------- 
  if GlobalActivatedCardID == 34086406 then  -- Lavalval Chain
   if GlobalCardMode == nil then
   for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 05361647 then -- Battlin' Boxer Glassjaw 
		  result[1] = i
		  GlobalActivatedCardID = nil
		  return result
         end
       end
     end	
   end 
 end 
 
  --------------------------------------------     
  -- Select "Battlin' Boxer Glassjaw" if possible
  --------------------------------------------   
  if GlobalActivatedEffectID == 68144350 then -- Battlin' Boxer Switchitter
	for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 05361647 then -- Battlin' Boxer Glassjaw   
		  result[1] = i
		  GlobalActivatedEffectID = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select "Battlin' Boxer Glassjaw" if possible
  --------------------------------------------   
  if GlobalActivatedEffectID == 79867938 then  -- Battlin' Boxer Headgeared
	for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 05361647 then -- Battlin' Boxer Glassjaw   
		  result[1] = i
		  GlobalActivatedEffectID = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select "Battlin' Boxer Glassjaw" if possible
  --------------------------------------------   
  if GlobalActivatedCardID == 36916401 then  -- Burnin' Boxin' Spirit
	for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].id == 05361647 then -- Battlin' Boxer Glassjaw     
		  result[1] = i
		  GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select AI's random spell/trap card in hand
  --------------------------------------------   
  if GlobalActivatedCardID == 00423585 then -- Summoner Monk
   if GlobalCardMode == 1 then   
	for i=1,#cards do
      if cards[i] ~= false then 
          result[1] = getRandomSTIndex(cards, 1)
		  GlobalCardMode = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select Battlin' Boxer Switchitter in AI's deck to summon
  --------------------------------------------   
  if GlobalActivatedCardID == 00423585 then -- Summoner Monk
   if GlobalCardMode == nil then   
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByIDNP(cards, 68144350, 1) -- Battlin' Boxer Switchitter
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end	
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 25774450 then -- Mystic Box
   if GlobalCardMode == 1 then   
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
		  GlobalCardMode = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select AI'S weakest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 25774450 then -- Mystic Box
   if GlobalCardMode == nil then   
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = LowestATKMonsterByOwnerIndex(cards, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end	
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 87880531 then -- Diffusion Wave-Motion
   local HighestATK = 0
   local HighestIndex = 1
    for i=1,#cards do
      if cards[i] ~= false then
        if bit32.band(cards[i].type,TYPE_MONSTER) == TYPE_MONSTER and cards[i].owner == 1 and cards[i].race == RACE_SPELLCASTER and
		 cards[i].level >= 7 and cards[i].attack > HighestATK then
          HighestIndex = i
          HighestATK = cards[i].attack
         return HighestIndex
		end
      end
    end
  end
  
  --------------------------------------------     
  -- Select any material to detach.
  --------------------------------------------   
  if GlobalActivatedCardID == 29669359 then -- Number 61: Volcasaurus
    if GlobalCardMode == 1 then
	GlobalCardMode = nil
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = i
		  return result
         end
       end
     end	
   end	
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 29669359 then -- Number 61: Volcasaurus 
    if GlobalCardMode == nil then
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  end
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 18807108 then -- Spellbinding Circle 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
		  GlobalActivatedCardID = nil 
		  return result
        end
      end
    end	
    
  --------------------------------------------     
  -- Select Players strongest lvl 5+ monster ot the field, or ritual summoned monster.
  --------------------------------------------   
  if GlobalActivatedCardID == 94192409 then -- Compulsory Evacuation Device 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByLevelOrSS(cards,TYPE_MONSTER+TYPE_RITUAL, 5, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end  	
  
  --------------------------------------------     
  -- Select AI's weakest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedEffectID == 40619825 then -- Axe of Despair
   if GlobalCardMode == 1 then
	for i=1,#cards do
      if cards[i] ~= false then 
		 result[1] = LowestATKMonsterByOwnerIndex(cards, 1)
          GlobalActivatedEffectID = nil
		  GlobalCardMode = nil
		  return result
        end
      end
    end	
  end
  
  --------------------------------------------     
  -- Select AI's weakest monster by attack points on the field.
  --------------------------------------------   
  if SpSummonedCardID == 34230233 then -- Grapha, Dragon Lord of Dark World
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = LowestATKMonsterByOwnerIndex(cards, 1)
          SpSummonedCardID = nil
		  return result
        end
      end
    end	
  
  --------------------------------------------     
  -- Select AI's weakest monster by attack points in hand.
  --------------------------------------------   
  if GlobalActivatedCardID == 70231910 then -- Dark Core 
   if GlobalCardMode == 1 then
	GlobalCardMode = nil 
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = LowestATKMonsterByOwnerIndex(cards, 1)
		 return result
        end
      end
    end	
  end
  --------------------------------------------     
  -- Select Players strongest monster by attack points on field.
  --------------------------------------------   
  if GlobalActivatedCardID == 70231910 then -- Dark Core 
   if GlobalCardMode == nil then
	for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
		 GlobalActivatedCardID = nil
		 return result
        end
      end
    end	
  end
  --------------------------------------------     
  -- Select AI's strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 83746708 then -- Mage Power 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 1)
         GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 68005187 then -- Soul Exchange 
	 for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	

  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 55713623 then -- Shrink 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
	
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 98045062 then -- Enemy Controller 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndexController(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
    
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 51945556 then -- Zaborg the Thunder Monarch 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end		
	
  --------------------------------------------     
  -- Select AI's monster by level in hand
  --------------------------------------------   
  if GlobalActivatedCardID == 23265313 then -- Cost Down 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = LowestATKMaxLevelIndex(cards, 4)
		  GlobalActivatedCardID = nil
		  return result
        end
      end
    end		
  
  --------------------------------------------     
  -- Chaos summons, check the cards to banish
  -- with the banish blacklist
  -- Check Lightpulsar Dragon separately when
  -- summoned from grave and discard cards
  -- that work well in the graveyard
  --------------------------------------------   
  if(GlobalActivatedCardID == 72989439      -- BLS
  or GlobalActivatedCardID == 09596126      -- Chaos Sorcerer
  or GlobalActivatedCardID == 99365553)     -- Lightpulsar Dragon
    and GlobalCardMode ~= nil then
    local discarding = 0
    if GlobalCardMode > 2 then
      discarding = 1
    end
    GlobalCardMode = GlobalCardMode - 1
    if GlobalCardMode <= 0 or GlobalCardMode == 2 then
      GlobalCardMode = nil 
      GlobalActivatedCardID = nil 
    end
    for i=1,#cards do
      if cards[i] and BanishBlacklist(cards[i].id) == 0 then 
        if discarding > 0 then
          if cards[i].id == 09411399 and AICardInGrave(cards[i].id) == 0    -- Destiny Hero - Malicious
          or cards[i].id == 33420078 or cards[i].id == 51858306             -- Plaguespreader Zombie, Eclipse Wyvern
          then
            return {i}
          end
        else
          if BanishWhitelist(cards[i].id) > 0 then
            return {i}
          end
        end
        result[#result+1] = i
      end
    end
    return {result[math.random(#result)]}
  end
  
  --------------------------------------------     
  -- Always put Destiny Hero - Malicious back in the deck
  -- if able. Otherwise one at random.
  --------------------------------------------   
  if GlobalActivatedCardID == 33420078 then -- Plaguespreader Zombie 
    GlobalActivatedCardID = nil
    if AICardInHand(09411399)>0 and AICardInGrave(09411399)>0 then
      for i=1,#cards do
        if cards[i] and cards[i].id == 09411399 then -- Destiny Hero - Malicious
          return {i}
        end
      end
    else
      return {math.random(#cards)}
    end
  end

  --------------------------------------------     
  -- Select Players strongest face-up monster 
  -- otherwise select a random one
  --------------------------------------------   
  if GlobalActivatedCardID == 15561463 then -- Gauntlet Launcher
    if GlobalCardMode == nil then
      GlobalCardMode = 1
      return {math.random(#cards)}
    end
    GlobalActivatedCardID = nil
    GlobalCardMode = nil
    if OppMonCountFaceUp() > 0 then
      result[1] = GetHighestATKMonByPos(cards,POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE,2)
      return result
    else
      for i=1,#cards do
        if cards[i] and (cards[i].owner == 2 or CurrentMonOwner(cards[i].id) == 2) then
          result[#result+1]=i
        end
      end
      return {result[math.random(#result)]}
    end
  end	

  --------------------------------------------
  -- For the banish, try to avoid monsters, that
  -- work well in the grave and check the banish blacklist
  --
  -- For the destruction, select players strongest monster, if 
  -- he controls any stronger monsters than AI or only monsters, 
  -- otherwise select any spell or trap card player controls
  --------------------------------------------   
  if GlobalActivatedCardID == 65192027 then -- Dark Armed Dragon
    if GlobalCardMode == 1 then  --banish from grave
      for i=1,#cards do
        if cards[i] then
          if BanishBlacklist(cards[i].id)==0 and cards[i].id ~= 33420078  -- Plaguespreader Zombie
            and (cards[i].id ~= 09411399 or AICardInDeck(cards[i].id)==0) -- Destiny Hero - Malicious
          then
            result[#result+1]=i
          end
        end
      end
      if #result <= 0 then
        for i=1,#cards do
          if cards[i] and BanishBlacklist(cards[i].id)==0 then
            result[#result+1]=i
          end
        end
      end
      result = {result[math.random(#result)]}
      GlobalCardMode = nil
      return result
    else              --destroy player card
      for i=1,#cards do
        if cards[i] ~= false then 
          if GetAIMonstersHighestATK() < GetOppMonstersHighestAPosATK() or OppSTCount()== 0 then 
            result[1] = GetHighestATKMonByPos(cards,POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE,2)
          else
            result[1] = getRandomSTIndex(cards, 2)
          end
          GlobalActivatedCardID = nil
          return result
        end
      end
    end
  end

 --------------------------------------------     
  -- Select monsters that work well in the grave, 
  -- otherwise just check for bosses
  -------------------------------------------- 
  if GlobalActivatedCardID == 14536035 then -- Dark Grepher
    local preferred={}
    for i=1,#cards do
      if cards[i] then
        if cards[i].id == 09411399 and AICardInGrave(cards[i].id) == 0 or    -- Destiny Hero - Malicious
           cards[i].id == 33420078 and AICardInGrave(cards[i].id) == 0       -- Plaguespreader Zombie
        then 
          preferred[#preferred+1]=i
        end
        if BanishBlacklist(cards[i].id) == 0 then
          result[#result+1]=i
        end
      end
    end
    if #preferred > 0 then 
      result = preferred 
    end
    if GlobalCardMode == 2 then
      GlobalCardMode = 1
    else
      GlobalActivatedCardID = nil
      GlobalCardMode = nil
    end
    result={result[math.random(#result)]}
    return result
  end

  --------------------------------------------------------
  -- For the banish on summon, check for banish blacklist, 
  -- select random valid target. Try to avoid XYZ dragons
  -- who still have materials, but use them if you have to.
  -- For the summoned dragon, prefer Lightpulsar (he can
  -- revive REDMD when destroyed) otherwise select at random
  --------------------------------------------------------
  if GlobalActivatedCardID == 88264978 then     -- Red-Eyes Darkness Metal Dragon
    GlobalActivatedCardID = nil
    if GlobalCardMode == 1 then
      for i=1,#cards do
        if BanishBlacklist(cards[i].id) == 0 and cards[i].xyz_material_count == 0 then
          result[#result+1]=i
        end
      end
      if #result == 0 then
        for i=1,#cards do
          if BanishBlacklist(cards[i].id) == 0 then
            result[#result+1]=i
          end
        end
      end
      GlobalCardMode = nil
      return {result[math.random(#result)]}
    else
      for i=1,#cards do
        if cards[i] and cards[i].id == 99365553 then --Lightpulsar Dragon
          return {i}
        end
      end
      return {math.random(#cards)}
    end
  end
  
  --------------------------------------------     
  -- Detach first 2 materials
  -- Destroy strongest face-up enemy monster
  -- Destroy random spell/trap card
  --------------------------------------------   
  if GlobalActivatedCardID == 75253697 then -- Number 72: Line Monster Chariot Hishna
    if GlobalCardMode == nil then
      GlobalCardMode = 1
      return {1,2}
    elseif GlobalCardMode == 1 then
      GlobalCardMode = 2
      return {GetHighestATKMonByPos(cards,POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE,2)}
    elseif GlobalCardMode == 2 then
      GlobalCardMode = nil
      return {math.random(#cards)}
    end
  end	

  -------------------------------------------- 
  -- Make Hieratic Dragon King of Atum always 
  -- summon Red Eyes Darkness Metal Dragon, if possible
  --------------------------------------------   
  if GlobalActivatedCardID == 27337596 then -- Hieratic Dragon King of Atum
    if GlobalCardMode == nil then
      GlobalCardMode = 1
      return {math.random(#cards)}
    end
    GlobalCardMode = nil
    for i=1,#cards do
      if cards[i] and cards[i].id == 88264978 then -- Red-Eyes Darkness Metal Dragon
        return {i}
      end
    end
    return {math.random(#cards)}
  end		
  
 --------------------------------------------     
  -- Search Tefnuit, if he is not in hand already
  -- otherwise, search Su. 
  -- If it doesn't find either, pick at random
  --------------------------------------------   
  if GlobalActivatedCardID == 25377819 then -- Hieratic Seal of Convocation
    GlobalActivatedCardID = nil
    local id = 77901552 -- Hieratic Dragon of Tefnuit
    if AICardInHand(id)>0 then
      id = 03300267 -- Hieratic Dragon of Su
    end
    for i=1,#cards do
      if cards[i] and cards[i].id == id then
        return {i}
      end
    end
    return {math.random(#cards)}
  end
  
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 29267084 then -- Shadow Spell 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
	
  --------------------------------------------     
  -- Select Players strongest monster by attack points on the field.
  --------------------------------------------   
  if GlobalActivatedCardID == 22046459 then -- Megamorph 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = HighestATKMonsterIndex(cards, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end	
	
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's normal type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 05183693 then -- Amulet of Ambition   
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByType(cards, TYPE_MONSTER+TYPE_NORMAL, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
	
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's normal type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 50078509 then -- Fiendish Chain   
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByType(cards, TYPE_MONSTER + TYPE_EFFECT, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end 	
  
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 91595718 or -- Book of Secret Arts
     GlobalActivatedCardID == 53610653 then -- Bound Wand
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByRace(cards, RACE_SPELLCASTER, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 46009906 then -- Beast Fangs
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByRace(cards, RACE_BEAST, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 88190790 then -- Assault Armor
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByRace(cards, RACE_WARRIOR, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 86198326 or  -- 7 Completed
      GlobalActivatedCardID == 63851864 then -- Break! Draw!
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByRace(cards, RACE_MACHINE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
    
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 18937875 then -- Burning Spear
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByAttribute(cards, ATTRIBUTE_FIRE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
   
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Ai's specified type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 39897277 or GlobalActivatedCardID == 82878489 then -- Elf's Light, Shine Palace
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByAttribute(cards, ATTRIBUTE_LIGHT, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 53586134 then -- Bubble Blaster   
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 79979666, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- select any face down card controlled by player (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 93554166 then -- Dark World Lightning 
    if GlobalCardMode == 1 then
	GlobalCardMode = nil
	for i=1,#cards do
      if cards[i] ~= false then 
        if cards[i].owner == 2 and cards[i].position == POS_FACEDOWN then  
		 result[1] = i
		  GlobalActivatedCardID = nil
		  return result
         end
       end
     end
   end
 end 	
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 46910446 then -- Chthonian Alliance 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonBySameID(cards, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end 
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 00303660 then -- Amplifier 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 77585513, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 40830387 or -- Ancient Gear Fist
     GlobalActivatedCardID == 37457534 then -- Ancient Gear Tank 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 
         50933533 or 31557782 or 
         10509340 or 80045583 or 
         01953925 or 86321248 or 
         83104731 or 39303359 or 
         56094445 or 500000006, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
         GlobalActivatedCardID = nil
		 return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 79965360 then -- Amazoness Heirloom 
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 
         91869203 or 10979723 or 
         73574678 or 29654737 or
         55821894 or 47480070 or
         15951532 or 53162898 or
         71209500 or 94004268 or 
		 89567993, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
         GlobalActivatedCardID = nil
		 return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 19596712 or -- Abyss-scale of Cetus
      GlobalActivatedCardID == 72932673 or -- Abyss-scale of the Mizuchi
      GlobalActivatedCardID == 08719957 then -- Abyss-scale of the Kraken       
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 
         74298287 or 75180828 or
         74371660 or 69293721 or 
         96682430 or 37781520 or
         23899727 or 95466842 or
         21767650 or 21954587 or
         00282886 or 58471134 or
         22446869 or 59170782 or
         22076135 or 28577986, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
         GlobalActivatedCardID = nil
		 return result
        end
      end
    end
    
  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's monster of specified id with strongest attack (for now)
  --------------------------------------------   
   if GlobalActivatedCardID == 59385322 then -- Core Blaster       
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByID(cards, 
         39037517 or 80367387 or
         06320631 or 32314730 or 
         80925836 or 12435193 or
         05817857 or 41201555 or
         45041488 or 31692182 or
         54520292 or 65026212 or
         19642889 or 00176392 or
         10060427 or 49680980 or
         74576482 or 68809475 or
         95204084 or 30936186 or
         72258771 or 66816282 or   
         95090813, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1) 
         GlobalActivatedCardID = nil
		 return result
        end
      end
    end

  --------------------------------------------
  -- Make sure Ai uses power up cards only on his own monsters,
  -- select Ai's attack pos monster with strongest attack, 
  -- whos attack is equal or below 1000 (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 84740193 then -- Buster Rancher    
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByAttLower(cards, 1000, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 1)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
    
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Opp's attack pos monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 41587307 or -- Broken Bamboo Sword
     GlobalActivatedCardID == 46967601 or -- Cursed Bill
     GlobalActivatedCardID == 56948373 or -- Mask of the accursed  
     GlobalActivatedCardID == 75560629 then -- Flint     
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByPos(cards, POS_FACEUP_ATTACK, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Make sure Ai uses equip cards with negative effects
  -- only on opponents monsters
  -- select Opp's non machine type monster with strongest attack (for now)
  --------------------------------------------   
  if GlobalActivatedCardID == 24668830 or -- Germ Infection
     GlobalActivatedCardID == 50152549 then -- Paralyzing Potion
    for i=1,#cards do
      if cards[i] ~= false then 
         result[1] = GetHighestATKMonByNonRace(cards, RACE_MACHINE, POS_FACEUP_ATTACK or POS_FACEUP_DEFENCE, 2)
          GlobalActivatedCardID = nil
		  return result
        end
      end
    end
  
  --------------------------------------------
  -- Discard all possible monster type cards
  --------------------------------------------   
  if GlobalActivatedCardID == 41142615 then -- The Cheerful Coffin 
	local DiscardCount= 1
	for i=1,#cards do
      if cards[i] ~= false then 
         if bit32.band(cards[i].type,TYPE_MONSTER) == TYPE_MONSTER and cards[i].setcode == 6 then
		  result[DiscardCount]= i;
		  GlobalActivatedCardID = nil
		  if (DiscardCount<maxTargets) then DiscardCount=DiscardCount+1 else break end
          end
        end
       end
	 return result
    end
  
  --------------------------------------------
  -- Discard all possible "Dark world" monster cards 
  --------------------------------------------   
  if GlobalActivatedCardID == 47217354 then -- Fabled Raven
	local DiscardCount= 1
	for i=1,#cards do
      if cards[i] ~= false then 
         if bit32.band(cards[i].type,TYPE_MONSTER) == TYPE_MONSTER and cards[i].setcode == 6 then
		  result[DiscardCount]= i;
		  GlobalActivatedCardID = nil
		  if (DiscardCount<maxTargets) then DiscardCount=DiscardCount+1 else break end
          end
        end
       end
	 return result
    end
  
  --------------------------------------------
  -- Banish monster's from AI's grave only, and select max available count
  --------------------------------------------   
  if GlobalActivatedCardID == 05758500 then -- Soul Release 
	local BanishCount= 1
	for i=1,#cards do
      if cards[i] ~= false then 
         if bit32.band(cards[i].type,TYPE_MONSTER) == TYPE_MONSTER and cards[i].owner == 1 then
		  result[BanishCount]= i;
		  GlobalActivatedCardID = nil
		  if (BanishCount<maxTargets) then BanishCount=BanishCount+1 else break end
          end
        end
       end
	 return result
    end
  	
	--------------------------------------------
  -- Banish monster's from AI's grave only, and select max available count
  --------------------------------------------   
  if GlobalActivatedCardID == 43973174 then -- The Flute of Summoning Dragon 
	local SummonCount= 1
	local HighestATK   = 0
	for i=1,#cards do
      if cards[i] ~= false then 
         if (bit32.band(cards[i].type,TYPE_MONSTER) == TYPE_MONSTER and cards[i].race == RACE_DRAGON) and cards[i].attack >= HighestATK then	  
		  HighestATK = cards[i].attack
		  result[SummonCount]= i;
		  GlobalActivatedCardID = nil
		  if (SummonCount<maxTargets) then SummonCount=SummonCount+1 else break end
          end
        end
       end
	 return result
    end
	
  -----------------------------------------------------------
  -- If the AI activates Monster Reborn, Call of the Haunted,
  -- or other special-summon cards (to be added later), let
  -- it choose the monster with the highest ATK for now.
  -----------------------------------------------------------
  if GlobalActivatedCardID == 83764718 or   -- Reborn
     GlobalActivatedCardID == 97077563 or   -- Call
     GlobalActivatedCardID == 88264978 or   -- REDMD
     GlobalActivatedCardID == 78868119 or   -- Diva
     GlobalActivatedCardID == 09622164 or   -- D.D.R.
     GlobalActivatedCardID == 71453557 or   -- Autonomous Action Unit
	 GlobalActivatedCardID == 42534368 or   -- Silent Doom
	 GlobalActivatedCardID == 43434803 or   -- The Shallow Grave
	 GlobalActivatedCardID == 93431518 or   -- Gateway to Dark World
	 GlobalActivatedCardID == 37694547 then -- Geartown    
	local HighestATK = 0
    local HighestIndex = 1
    for i=1,#cards do
      if cards[i] ~= false then
        if cards[i].attack > HighestATK then
          HighestIndex = i
          HighestATK = cards[i].attack
        end
      end
    end
    GlobalActivatedCardID = nil
    result[1] = HighestIndex
    return result
  end
  

    
  -------------------------------------------------------
  -- If the AI activates Tour Guide from the Underworld's
  -- effect, attempt to special summon something other
  -- than another Tour Guide.
  -------------------------------------------------------
  if GlobalActivatedCardID == 10802915 then
    for i=1,#cards do
      if cards[i] ~= false then
        if cards[i].id ~= 10802915 then
          GlobalActivatedCardID = nil
          result[1] = i
          return result
        end
      end
    end
  end


  -----------------------------------------------------
  -- When Monster Reincarnation resolves, the AI should
  -- always choose the monster with the highest ATK
  -- that isn't an extra deck monster.
  -----------------------------------------------------
  if GlobalActivatedCardID == 74848038 then
    if GlobalCardMode == nil then
      GlobalActivatedCardID = nil
      result[1] = HighestATKEffMonsterIndex(cards,TYPE_MONSTER+TYPE_EFFECT)
      return result
    end
  end


  -----------------------------------------------------------
  -- When Lumina, Lightsworn Summoner resolves, the AI should
  -- always choose the monster with the highest ATK for now.
  --
  -- To do: choose the right monster depending on the situation.
  -- (Wulf/Jain for ATK, Lyla for S/T, Ehren for DEF monsters,
  --  Garoth for draw power if no threats are present, more?)
  -----------------------------------------------------------
  if GlobalActivatedCardID == 95503687 then
    if GlobalCardMode == nil then
      GlobalActivatedCardID = nil
      result[1] = HighestATKEffMonsterIndex(cards,TYPE_MONSTER+TYPE_EFFECT)
      return result
    end
  end

  ------------------------------------------------------------
  -- For the Monster Reincarnation discard cost, the AI should
  -- simply discard the lowest ATK monster card in hand.
  ------------------------------------------------------------
  if GlobalActivatedCardID == 74848038 then
    if GlobalCardMode == 1 then
      GlobalCardMode = nil
      result[1] = LowestATKMonsterIndex(cards)
      return result
    end
  end


  ----------------------------------------------------------------
  -- For Lumina, Lightsworn Summoner's discard cost, the AI should
  -- discard the lowest ATK monster whose level is 5 or lower.
  ----------------------------------------------------------------
  if GlobalActivatedCardID == 95503687 then
    if GlobalCardMode == 1 then
      GlobalCardMode = nil
      result[1] = LowestATKMaxLevelIndex(cards, 5)
      return result
    end
  end

  ----------------------------------------------------------------
  -- For Mecha Phantom Beast Dracossack's tributing cost
  -- tribute only his summoned Mecha Tokens.
  ----------------------------------------------------------------
  if GlobalActivatedCardID == 22110647 then 
	if GlobalCardMode == 1 then
     GlobalCardMode = nil
     for i=1,#cards do
     if cards[i] ~= false then
      if cards[i].id ~= 22110647 and cards[i].attack == 0 then
      result[1] = i
	    return result
        end
      end
     end
   end
  end
   
  ----------------------------------------------------------------
  -- Target Player's monster with highest attack when 
  -- Mecha Phantom Beast Dracossack's card destroy effect is used.
  ----------------------------------------------------------------
   if GlobalActivatedCardID == 22110647 then
	if GlobalCardMode == nil then
      GlobalActivatedCardID = nil
      result[1] = HighestATKMonsterIndex(cards, 2)
	  return result
    end
  end
 
  -------------------------------------------------------
  -- Charge of the Light Brigade: The AI should never add
  -- Wulf, Lightsworn Beast to hand. Anything else is OK.
  -------------------------------------------------------
  if GlobalActivatedCardID == 94886282 then
    for i=1,#cards do
      if cards[i] ~= false then
        if cards[i].id ~= 58996430 then
          GlobalActivatedCardID = nil
          result[1] = i
          return result
        end
      end
    end
  end  


  ---------------------------------------------------------
  -- When the effect of Tanngnjostr of the Nordic Beasts is
  -- activated, try to special summon a tuner or a level 3
  -- Nordic Beast monster.
  ---------------------------------------------------------
  if GlobalActivatedCardID == 14677495 then
    for i=1,#cards do
      if cards[i] ~= false then
        if IsNordicTuner(cards[i].id) == 1 or
           cards[i].level == 3 then
          GlobalActivatedCardID = nil
          result[1] = i
          return result
        end
      end
    end
  end


  -------------------------------------------------
  -- When activating Toon Table of Contents, search
  -- another copy of Toon Table to thin the deck.
  -------------------------------------------------
  if GlobalActivatedCardID == 89997728 then
    for i=1,#cards do
      if cards[i] ~= false then
        if cards[i].id == 89997728 then
          GlobalActivatedCardID = nil
          result[1] = i
          return result
        end
      end
    end
  end  


  --------------------------------------------------------
  -- After activating Dark World Dealings, the AI should
  -- look for and discard a Dark World monster if one
  -- exists in hand. If not, then discard another monster.
  --------------------------------------------------------
  if GlobalActivatedCardID == 74117290 then
    for i=1,#cards do
      if cards[i] ~= false then
		if AICardInHand(34230233) == 1 then
		  GlobalActivatedCardID = nil
          result[1] = GetHighestATKMonByIDNP(cards, 34230233, 1)
		  return result
        end
      end
    end
	for i=1,#cards do
      if cards[i] ~= false then
		if IsDiscardEffDWMonster(cards[i].id) == 1 then
          GlobalActivatedCardID = nil
          result[1] = i
		  return result
        end
      end
    end
    for i=1,#cards do
      if cards[i] ~= false then
        if bit32.band(cards[i].type,TYPE_MONSTER) > 0 then
          GlobalActivatedCardID = nil
          result[1] = i
		  return result
        end
      end
    end
  end


  ----------------------------------------------------------
  -- When paying the banish cost of The Gates of Dark World,
  -- the AI should choose to banish something other than
  -- Grapha, Dragon Lord of Dark World.
  --
  -- To do: Restrict this to level 4 or lower monsters?
  ----------------------------------------------------------
  if GlobalActivatedCardID == 33017655 then
    if GlobalCardMode == 1 then
      GlobalCardMode = nil
      local AIGrave = AI.GetAIGraveyard()
      for i=1,#AIGrave do
        if AIGrave[i].id ~= 34230233 then
          GlobalCardMode = nil
          result[1] = i
          return result
        end
      end
    end
  end


  -------------------------------------------------
  -- If every selectable card is a Dark World card,
  -- the activated Card ID isn't known, and the
  -- minimum and maximum targets are both 1, that
  -- means it's most likely a triggered Snoww
  -- search effect.
  --
  -- For that, search The Gates of Dark World if
  -- the AI doesn't already control it or has it 
  -- in hand. Search Dark World Dealings if no
  -- Gates in hand, field, or deck. Otherwise add
  -- the highest ATK monster.
  --
  -- To do: improve this when trigger effects can
  --        be detected more easily.
  -------------------------------------------------
  if GlobalActivatedCardID == nil then
    if minTargets == 1 and maxTargets == 1 and
       AllCardsArchetype(cards,6) == 1 then
      if AIControlsFaceupST(33017655) ~= 1 and
         AICardInHand(33017655) ~= 1 then
        for i=1,#cards do
          if cards[i].id == 33017655 then
            result[1] = i
            return result
          end
        end
        for i=1,#cards do
          if cards[i].id == 74117290 then
            result[1] = i
            return result
          end
        end
      end
      local HighestAttack = 0
      local HighestIndex  = 1
      for i=1,#cards do
        if cards[i].attack > HighestAttack then
          HighestAttack = cards[i].attack
          HighestIndex = i
        end
      end
      result[1] = HighestIndex
      return result
    end
  end                                                            

 
  -------------------------------------------------
  -- When the AI activates Lavalval Chain's effect,
  -- it will most likely be the "send a card to the
  -- grave" effect. Look for and choose the first
  -- monster card for now.
  -------------------------------------------------
  if GlobalActivatedCardID == 34086406 then
    for i=1,#cards do
      if bit32.band(cards[i].type,TYPE_MONSTER) > 0 then
        GlobalActivatedCardID = nil
        result[1] = i
        return result
      end
    end
  end

 
  --------------------------------------------
  -- For Worm Xex's effect, the AI should look
  -- for and send Worm Yagan to the grave.
  --------------------------------------------
  if GlobalActivatedCardID == 11722335 then
    for i=1,#cards do
      if cards[i].id == 47111934 then
        GlobalActivatedCardID = nil
        result[1] = i
        return result
      end
    end
  end

  -------------------------------------
  -- The AI should tribute a card other
  -- than Worm King for its effect!
  -------------------------------------
  if GlobalActivatedCardID == 10026986 then
    if GlobalCardMode == 1 then
      GlobalCardMode = nil
      for i=1,#cards do
        if cards[i].id ~= 10026986 then
          result[1] = LowestATKMonsterIndex(cards)
          return result
        end
      end
    end
  end
     
  -----------------------------------------------
  -- If every selectable card is a Worm monster
  -- card, the activated Card ID isn't known, and
  -- the minimum and maximum targets are both 1,
  -- that means it's probably Worm Cartaros' flip
  -- search effect.
  -- When it's flipped, the AI should add Xex if
  -- possible. Otherwise add the first occurring
  -- monster (for now, anyway).
  -----------------------------------------------
  if GlobalActivatedCardID == nil then
    if minTargets == 1 and maxTargets == 1 and
       AllCardsArchetype(cards,62) then
      for i=1,#cards do
        if cards[i].id == 11722335 then
          result[1] = i
          return result
        end
      end
    end
  end
  
  -----------------------------------------------
  -- If every selectable card is a "Battlin' Boxer"
  -- card, the activated Card ID isn't known, and
  -- the minimum and maximum targets are both 1 then it's most likely 
  -- "Battlin' Boxer Glassjaw's" add card effect, try to add 
  -- "Battlin' Boxer Switchitter" if possible.
  -----------------------------------------------
  if GlobalActivatedCardID == nil then
    if minTargets == 1 and maxTargets == 1 and
       AllCardsArchetype(cards,132) then 
      for i=1,#cards do
        if cards[i].id == 68144350 then -- Battlin' Boxer Switchitter
          result[1] = i
          return result
        end
      end
    end
  end
  
  -----------------------------------------------
  -- Certain cards should discard the correct
  -- Dark World monster for the situation.
  -- If the opp controls a card, discard Grapha.
  -- If a monster, discard Kahkki. S/T, Gren.
  -- If no Gates in hand or field, Snoww.
  -- If not that, the first effective DW monster.
  -- Otherwise the first card found.
  -----------------------------------------------
  if GlobalActivatedCardID == 33017655 or   -- The Gates of Dark World
	 GlobalActivatedCardID == 93554166 and  -- Dark World Lightning          
	 GlobalCardMode == nil             or 
	 GlobalActivatedCardID == 74117290 or   -- Dark World Dealings
     GlobalActivatedCardID == 94283662 or   -- Trance Archfiend
	 GlobalActivatedCardID == 81439173 then   -- Foolish Burial   
	if OppMonCount() > 0 or OppSTCount() > 0 then
      for i=1,#cards do
        if cards[i].id == 34230233 then
          GlobalActivatedCardID = nil
          result[1] = i
		  return result
        end
      end
    end
    if OppMonCount() > 0 then
      for i=1,#cards do
        if cards[i].id == 25847467 then
          GlobalActivatedCardID = nil
          result[1] = i
		  return result
        end
      end
    end
    if OppSTCount() > 0 then
      for i=1,#cards do
        if cards[i].id == 51232472 then
          GlobalActivatedCardID = nil
          result[1] = i
		  return result
        end
      end
    end
    if AIControlsFaceupST(33017655) ~= 1 and
       AICardInHand(33017655) ~= 1 then
      for i=1,#cards do
        if cards[i].id == 60228941 then
          GlobalActivatedCardID = nil
		  result[1] = i
          return result
        end
      end
    end
    for i=1,#cards do
      if IsDiscardEffDWMonster(cards[i].id) then
        GlobalActivatedCardID = nil
		result[1] = i
        return result
      end
    end
  end


  --------------------------------------------
  -- Reset these variable if it gets this far.
  --------------------------------------------
  GlobalActivatedCardID = nil
  GlobalCardMode = nil


  -- Example implementation: always choose the mimimum amount of targets and select the index of the first available targets
  for i=1,minTargets do
        result[i]=i
  end


  for i=1,minTargets do
    print(result[i]..'')
  end


  return result

end

