--- OnSelectPosition ---
--
-- Called when AI has to select the monster position.
-- 
-- Parameters (2):
-- id = card id
-- available = available positions
--
-- Return: the position
--[[
From constants.lua
POS_FACEUP_ATTACK		=0x1
POS_FACEDOWN_ATTACK		=0x2
POS_FACEUP_DEFENCE		=0x4
POS_FACEDOWN_DEFENCE	=0x8
--]]
function OnSelectPosition(id, available)
	local result = 0
	local band = bit32.band --assign bit32.band() to a local variable
  result = POS_FACEUP_ATTACK 
  
  -------------------------------------------------------
  -- If a dragon is summoned by the effect of a Hieratic 
  -- monster, always summon it in defense mode, as his 
  -- attack and defense will be 0
  -------------------------------------------------------
  if GlobalActivatedCardID == 27337596 -- Hieratic Dragon King of Atum
  then
    result = POS_FACEUP_DEFENCE
    GlobalActivatedCardID = nil
    GlobalTributedCardID = nil
  end
  
  ------------------------------------------------------
  -- Check if AI's monster's attack is lower than of strongest player's monster,
  -- or if any actions can be taken to gain advantage over player.
  -- Then summon or set monster in available position depending on results.
  ------------------------------------------------------
 if band(POS_FACEDOWN_DEFENCE,available) > 0 and Get_Card_Count_Pos(OppMon(), POS_FACEUP) > 0 then
  if AIMonGetAttackById(id) < Get_Card_Att_Def(OppMon(),"attack",">",POS_FACEUP_ATTACK,"attack") and CanChangeOutcomeSS(id) == 0 and AIMonGetAttackById(id) < 2400 then -- Also check if any action can be taken by CanChangeOutcomeSS
    result = POS_FACEDOWN_DEFENCE
    end 
  end
 if band(POS_FACEUP_DEFENCE,available) > 0 and Get_Card_Count_Pos(OppMon(), POS_FACEUP) > 0 then 
  if AIMonGetAttackById(id) < Get_Card_Att_Def(OppMon(),"attack",">",POS_FACEUP_ATTACK,"attack") and CanChangeOutcomeSS(id) == 0 and AIMonGetAttackById(id) < 2400 then -- Also check if any action can be taken by CanChangeOutcomeSS
   result = POS_FACEUP_DEFENCE
   end 
 end
  
  -------------------------------------------------------
  -- If Treeborn Frog is being special summoned, check if
  -- Creature Swap is in hand, the opponent controls 1
  -- monster, and the AI controls no other monsters.
  --
  -- If so, let the AI be a troll and special summon the
  -- frog in attack position!
  -------------------------------------------------------
  if id == 12538374 then
    if Get_Card_Count_ID(AIHand(),31036355,nil) == 0 or
       Get_Card_Count(OppMon()) ~= 1 or
       Get_Card_Count(AIMon()) ~= 0 then
      result = POS_FACEUP_DEFENCE
    end
  end

  ------------------------------------
  ------------------------------------复
  -- Cards to be always summoned in
  -- defence position.
  -- Expanding upon the above example.
  -- More cards to be added later.特招时守表
  ------------------------------------
  if id == 19665973 or id == 52624755 or   -- Battle Fader, Peten the Dark Clown,
     id == 10002346 or id == 87151205 or   -- Gachi Gachi, Redox
     id == 39552864 or id == 18326736 or   -- Gachi Gachi, Redox
     id == 23434538 or id == 54582424 or   -- Gachi Gachi, Redox
     id == 97268402 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 46772449 or id == 67696066 or   -- Gachi Gachi, Redox
     id == 23093604 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 44682448 or id == 33911264 or   -- Gachi Gachi, Redox
     id == 95466842 or id == 20932152 or   -- Gachi Gachi, Redox
     id == 43138260 or id == 97232518 or   -- Gachi Gachi, Redox
     id == 64319467 or id == 22404675 or   -- Gachi Gachi, Redox
     id == 02584136 or id == 95993388 or   -- Gachi Gachi, Redox
     id == 44330099 or id == 22382087 or   -- Gachi Gachi, Redox
     id == 34475451 or id == 58786132 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 33420078 or id == 15394084 or   -- Plaguespreader, Nordic Beast Token
     id == 58058134 or id == 10389142 or   -- Slacker Magician, Tomahawk
     id == 46384403 or id == 14677495 then -- Nimble Manta, Tanngnjostr
    
	result = POS_FACEUP_DEFENCE
  end
  

  -- Cards to be always summoned in
  -- attack position.
  -- Expanding upon the above example.
  -- More cards to be added later.特招时攻表
  ------------------------------------
  if id == 64631466 or id == 70908596 or   -- Relinquished, Constellar Kaust
id == 55727845 or id == 07194917 or
id == 16195942 or id == 20366274 or
id == 73964868 or id == 70908596 or
id == 21521304 or id == 86099788 or
id == 22110647 or id == 24874631 or
id == 64631466 or id == 43032236 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
id == 64631466 or id == 70908596 or
	 id == 23232295 or id == 88241506 then -- Battlin' Boxer Lead Yoke, Maiden with Eyes of Blue
	result = POS_FACEUP_ATTACK
  end
  -- Cards to be always summoned in
    ------------------------------------
  if id == 59170782 or id == 70908596   -- Relinquished, Constellar Kaust
	or id == 88241506 then -- Maiden with Eyes of Blue
	result = POS_FACEUP_ATTACK
  end

  -- attack position.
  -- Expanding upon the above example.复
  -- More cards to be added later.
  -- Cards to be always summoned in
  -- defence position.
  -- Expanding upon the above example.
  -- More cards to be added later.
  ------------------------------------
  if id == 19665973 or id == 52624755 or   -- Battle Fader, Peten the Dark Clown,
     id == 10002346 or id == 90411554 or   -- Gachi Gachi, Redox
     id == 33420078 or id == 15394084 or   -- Plaguespreader, Nordic Beast Token
     id == 58058134 or id == 10389142 or   -- Slacker Magician, Tomahawk
     id == 46384403 or id == 14677495 then -- Nimble Manta, Tanngnjostr
    
	result = POS_FACEUP_DEFENCE
  end
  
  ------------------------------------
  -- Cards to be always summoned in
  -- attack position.
  -- Expanding upon the above example.
  -- More cards to be added later.
  ------------------------------------
  if id == 64631466 or id == 70908596   -- Relinquished, Constellar Kaust
	or id == 88241506 then -- Maiden with Eyes of Blue
	result = POS_FACEUP_ATTACK
  end
  local positionfunctions={
  FireFistOnSelectPosition,HeraldicOnSelectPosition,GadgetOnSelectPosition,
  BujinOnSelectPosition,MermailOnSelectPosition,ShadollOnSelectPosition,
  SatellarknightOnSelectPosition,ChaosDragonOnSelectPosition,HATPosition,
  QliphortPosition,NoblePosition,NekrozPosition,BAPosition,
  DarkWorldPosition,ConstellarPosition,BlackwingPosition,
  GenericPosition,HarpiePosition,HEROPosition,
  }
  for i=1,#positionfunctions do
    local func = positionfunctions[i]
    if func then
      local Position = func(id,available)
      if Position then result=Position end
    end
  end
  local d = DeckCheck()
  if d and d.Position then
    local Position = d.Position(id,available)
    if Position then result=Position end
  end
  if result == nil then result = POS_FACEUP_ATTACK end
  if band(result,available) == 0 then
    if band(POS_FACEUP_ATTACK,available) > 0 then
      result = POS_FACEUP_ATTACK
    elseif band(POS_FACEUP_DEFENCE,available) > 0 then
      result = POS_FACEUP_DEFENCE
    elseif band(POS_FACEDOWN_DEFENCE,available) > 0 then
      result = POS_FACEDOWN_DEFENCE
    else
      result = POS_FACEDOWN_ATTACK
    end
  end
  return result
end
