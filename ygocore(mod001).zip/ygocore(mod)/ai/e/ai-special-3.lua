
require("ai.e.ai-LV3")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
TokenList={
}