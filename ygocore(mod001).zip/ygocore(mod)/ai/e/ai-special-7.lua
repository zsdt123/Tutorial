
require("ai.e.ai-LV7")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
TokenList={
}