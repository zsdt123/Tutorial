
require("ai.e.ai[AV]Action Duel")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
TokenList={
}