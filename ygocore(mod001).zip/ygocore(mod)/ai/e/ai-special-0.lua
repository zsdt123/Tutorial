require("ai.e.ai-special")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
notTokenList={

}