
require("ai.e.ai-LV4")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
TokenList={
}