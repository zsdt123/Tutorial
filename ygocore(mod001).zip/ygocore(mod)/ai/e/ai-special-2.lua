
require("ai.e.ai-LV2")

math.randomseed( require("os").time() )

function OnStartOfDuel()

	OnStartOfDuel_Boss()
end
TokenList={
}