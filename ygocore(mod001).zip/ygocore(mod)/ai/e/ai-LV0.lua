
Version = "0.28c"
Experimental = true

--[[
  AI Script for YGOPro Percy:
  http://www.ygopro.co/

  script by Snarky
  original script by Percival18
  
  GitHub repository: 
  https://github.com/Snarkie/YGOProAIScript/
  
  Check here for updates: 
  http://www.ygopro.co/Forum/tabid/95/g/posts/t/7877/AI-Updates
  
  Contributors: ytterbite, Sebrian, Skaviory, francot514
  
  for more information about the AI script, check the ai-template.lua
]]
function requireoptional(module)
  if not pcall(require,module) then
    --print("file missing or syntax error: "..module)
  end
end
require("ai.mod1.AICheckList")
require("ai.mod1.AIHelperFunctions")
require("ai.mod1.AIHelperFunctions2")
require("ai.mod1.AICheckPossibleST")
require("ai.mod1.AIOnDeckSelect")
require("ai.mod1.DeclareAttribute")
require("ai.mod1.DeclareCard")
require("ai.mod1.DeclareMonsterType")
require("ai.mod1.SelectBattleCommand")
require("ai.mod1.SelectCard")
require("ai.mod1.SelectChain")
require("ai.mod1.SelectEffectYesNo")
require("ai.mod1.SelectInitCommand")
require("ai.mod1.SelectNumber")
require("ai.mod1.SelectOption")
require("ai.mod1.SelectPosition")
require("ai.mod1.SelectSum")
require("ai.mod1.SelectTribute")
require("ai.mod1.SelectYesNo")
require("ai.decks1.Generic")
require("ai.decks1.FireFist")
require("ai.decks1.HeraldicBeast")
require("ai.decks1.Gadget")
require("ai.decks1.Bujin")
require("ai.decks1.Mermail")
require("ai.decks1.Shadoll")
require("ai.decks1.Satellarknight")
require("ai.decks1.ChaosDragon")
require("ai.decks1.HAT")
require("ai.decks1.Qliphort")
require("ai.decks1.NobleKnight")
require("ai.decks1.Necloth")
require("ai.decks1.BurningAbyss")
require("ai.decks1.DarkWorld")
require("ai.decks1.Constellar")
require("ai.decks1.Blackwing")
require("ai.decks1.Harpie")
require("ai.decks1.HERO")
require("ai.decks1.ExodiaLib")
require("ai.decks1.Boxer")


math.randomseed( require("os").time() )

function OnStartOfDuel()
	AI.Chat("")
	AI.Chat("")
	AI.Chat("")
	AI.Chat("")
	AI.Chat("你好,这是作弊等级2的AI,AI将在第二次抽卡后+2张,祝你游戏愉快")
  --Debug.SetAIName("AI-Cheater")
  GlobalCheating = 1
  SaveState()
end
