--
Nef = Nef or {}
local os = require("os")
function Nef.unpack(t, i)
    i = i or 1
    if t[i] then
       return t[i], Nef.unpack(t, i + 1)
    end
end

function Nef.unpackOneMember(t, member, i)
    i = i or 1
    if t[i] and t[i][member] then
       return t[i][member], Nef.unpackOneMember(t, member, i+1)
    end
end

function Nef.AddSynchroProcedureWithDesc(c,f1,f2,ct,desc)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_IGNORE_IMMUNE)
	e1:SetRange(LOCATION_EXTRA)
	e1:SetDescription(desc)
	e1:SetCondition(Auxiliary.SynCondition(f1,f2,ct,99))
	e1:SetOperation(Auxiliary.SynOperation(f1,f2,ct,99))
	e1:SetValue(SUMMON_TYPE_SYNCHRO)
	c:RegisterEffect(e1)
	return e1
end

function Nef.AddXyzProcedureWithDesc(c,f,lv,ct,desc,maxct)
	if c.xyz_filter==nil then
		local code=c:GetOriginalCode()
		local mt=_G["c" .. code]
		mt.xyz_filter=f
		mt.xyz_count=ct
	end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE)
	e1:SetRange(LOCATION_EXTRA)
	e1:SetDescription(desc)
	if not maxct then maxct=ct end
	e1:SetCondition(Auxiliary.XyzCondition(f,lv,ct,maxct))
	e1:SetOperation(Auxiliary.XyzOperation(f,lv,ct,maxct))
	e1:SetValue(SUMMON_TYPE_XYZ)
	c:RegisterEffect(e1)
	return e1
end

function Auxiliary.AddPendulumProcedure(c)
	local argTable = {1}
	Nef.AddPendulumProcedureSP(c,99,Auxiliary.TRUE,argTable)
end

function Nef.AddPendulumProcedureSP(c,num,filter,argTable,tag)
	if c.pend_filter==nil then
		local code=c:GetOriginalCode()
		local mt=_G["c" .. code]
		mt.pend_filter=filter
		mt.pend_arg=argTable
		mt.pend_num=num
		mt.pend_tag=tag
	end
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_FIELD)
	e1:SetCode(EFFECT_SPSUMMON_PROC_G)
	e1:SetProperty(EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_CANNOT_DISABLE)
	e1:SetRange(LOCATION_PZONE)
	e1:SetCondition(Nef.PendConditionSP(filter,argTable))
	e1:SetOperation(Nef.PendOperationSP(num,filter,argTable))
	e1:SetValue(SUMMON_TYPE_PENDULUM)
	c:RegisterEffect(e1)
	--disable spsummon
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_FIELD)
	e2:SetRange(LOCATION_PZONE)
	e2:SetCode(EFFECT_CANNOT_SPECIAL_SUMMON)
	e2:SetProperty(EFFECT_FLAG_PLAYER_TARGET+EFFECT_FLAG_UNCOPYABLE+EFFECT_FLAG_CANNOT_DISABLE)
	e2:SetTargetRange(1,0)
	e2:SetTarget(Nef.PendSummonLimitTarget)
	c:RegisterEffect(e2)
end

function Nef.PendSummonCheck(c,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,pendCard)
	local code=pendCard:GetOriginalCode()
	local mt=_G["c" .. code]
	if mt.pend_tag then
		if mt.pend_tag == "GodSprite" then
			return c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_PENDULUM,tp,true,false)
		end
	else
		return c:IsCanBeSpecialSummoned(e,SUMMON_TYPE_PENDULUM,tp,false,false)
	end
end

function Nef.PConditionFilterSP(c,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz,rpz)
	local lv=c:GetLevel()
	local normalCondition = (c:IsLocation(LOCATION_HAND) or (c:IsFaceup() and c:IsType(TYPE_PENDULUM)))
		and lv>lscale and lv<rscale 
		and Nef.PendSummonCheck(c,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz) 
		and Nef.PendSummonCheck(c,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,rpz)
	local spCondition = filter(c,Nef.unpack(argTable)) and filter2(c,Nef.unpack(argTable2))
	return spCondition and normalCondition
end

function Nef.PendConditionSP(filter,argTable)
	return	function(e,c,og)
				if c==nil then return true end
				local tp=c:GetControler()
				if Duel.GetFlagEffect(tp,10000000)~=0 then return false end

				local lpz=Duel.GetFieldCard(tp,LOCATION_SZONE,6)
				local rpz=Duel.GetFieldCard(tp,LOCATION_SZONE,7)
				if not (lpz and rpz) then return false end
				if c==rpz and _G["c" .. lpz:GetOriginalCode()].pend_filter then return false end

				local filter2 = Auxiliary.TRUE
				local argTable2 = {1}
				local temp = (c==lpz and rpz or lpz)
				local code = temp:GetOriginalCode()
				local mt = _G["c" .. code]
				filter2 = (mt.pend_filter~=nil and mt.pend_filter or filter2)
				argTable2 = (mt.pend_arg~=nil and mt.pend_arg or argTable2)

				local lscale=lpz:GetLeftScale()
				local rscale=rpz:GetRightScale()
				if lscale>rscale then lscale,rscale=rscale,lscale end
				local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
				if ft<=0 then return false end
				if og then
					return og:IsExists(Nef.PConditionFilterSP,1,nil,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz,rpz)
				else
					return Duel.IsExistingMatchingCard(Nef.PConditionFilterSP,tp,LOCATION_HAND+LOCATION_EXTRA,0,1,nil,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz,rpz)
				end
			end
end

function Nef.PendOperationSP(num,filter,argTable)
	return	function(e,tp,eg,ep,ev,re,r,rp,c,sg,og)
				Duel.RegisterFlagEffect(tp,10000000,RESET_PHASE+PHASE_END,0,1)
				local lpz=Duel.GetFieldCard(tp,LOCATION_SZONE,6)
				local rpz=Duel.GetFieldCard(tp,LOCATION_SZONE,7)

				local filter2 = Auxiliary.TRUE
				local argTable2 = {1}
				local n2 = 99
				local temp = (c==lpz and rpz or lpz)
				local code = temp:GetOriginalCode()
				local mt = _G["c" .. code]
				filter2 = (mt.pend_filter~=nil and mt.pend_filter or filter2)
				argTable2 = (mt.pend_arg~=nil and mt.pend_arg or argTable2)
				n2 = (mt.pend_num~=nil and mt.pend_num or n2)
				
				local lscale=lpz:GetLeftScale()
				local rscale=rpz:GetRightScale()
				if lscale>rscale then lscale,rscale=rscale,lscale end
				local ft=Duel.GetLocationCount(tp,LOCATION_MZONE)
				local n1 = (ft>num and num or ft)
				n1 = (n1>n2 and n2 or n1)
				if og then
					Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
					local g=og:FilterSelect(tp,Nef.PConditionFilterSP,1,n1,nil,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz,rpz)
					sg:Merge(g)
				else
					Duel.Hint(HINT_SELECTMSG,tp,HINTMSG_SPSUMMON)
					local g=Duel.SelectMatchingCard(tp,Nef.PConditionFilterSP,tp,LOCATION_HAND+LOCATION_EXTRA,0,1,n1,nil,e,tp,lscale,rscale,filter,argTable,filter2,argTable2,lpz,rpz)
					sg:Merge(g)
				end
			end
end

function Nef.PendSummonLimitTarget(e,c,sump,sumtype,sumpos,targetp)
	local c = nil
	if e then c = e:GetHandler() end
	return c and sumtype==SUMMON_TYPE_PENDULUM and _G["c" .. c:GetOriginalCode()].pend_filter==nil
end

function Nef.EnableDualAttributeSP(c)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_DUAL_SUMMONABLE)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	c:RegisterEffect(e1)
end

function Nef.EnableDualAttribute(c, flag)
	local e1=Effect.CreateEffect(c)
	e1:SetType(EFFECT_TYPE_SINGLE)
	e1:SetCode(EFFECT_DUAL_SUMMONABLE)
	e1:SetProperty(EFFECT_FLAG_CANNOT_DISABLE)
	c:RegisterEffect(e1)
	local e2=Effect.CreateEffect(c)
	e2:SetType(EFFECT_TYPE_SINGLE)
	e2:SetCode(EFFECT_CHANGE_TYPE)
	e2:SetProperty(EFFECT_FLAG_SINGLE_RANGE)
	e2:SetRange(LOCATION_MZONE)
	e2:SetCondition(aux.DualNormalCondition)
	e2:SetValue(TYPE_NORMAL+TYPE_DUAL+TYPE_MONSTER+flag)
	c:RegisterEffect(e2)
end

function Nef.IsDate(Year, Month, Day)
	local year = Year or -1
	local month = Month or -1
	local day = Day or -1
	local date = os.date("*t")
	return (date.year==year or year<0) and (date.month==month or month<0) and (date.day==day or day<0)
end

function Nef.GetDate()
	local date = os.date("*t")
	return date.year, date.month, date.day
end