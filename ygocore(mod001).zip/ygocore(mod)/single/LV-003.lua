--puzzle1
Debug.SetAIName("Level-003")
Debug.ReloadFieldBegin(DUEL_ATTACK_FIRST_TURN+DUEL_SIMPLE_AI)
Debug.SetPlayerInfo(0,200,0,0)
Debug.SetPlayerInfo(1,1800,0,0)

Debug.AddCard(58074572,0,0,LOCATION_HAND,0,POS_FACEDOWN)
Debug.AddCard(58074572,0,0,LOCATION_HAND,0,POS_FACEDOWN)
Debug.AddCard(19523799,0,0,LOCATION_HAND,0,POS_FACEDOWN)
Debug.AddCard(46918794,0,0,LOCATION_HAND,0,POS_FACEDOWN)

Debug.ReloadFieldEnd()
Debug.ShowHint("GAME START!")
aux.BeginPuzzle()
